package sorting_networks.test;

import org.junit.jupiter.api.Test;
import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

import static org.junit.jupiter.api.Assertions.*;

class NetworkBinaryTesterTest {

    Network getNetworkSize3AndValid() {
        var network = new SimpleNetwork(3);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(0 ,1)
        );
        return network;
    }

    Network getNetworkSize3AndInvalid() {
        var network = new SimpleNetwork(3);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2)
        );
        return network;
    }

    Network getNetworkSize4AndValid() {
        var network = new SimpleNetwork(4);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(0 ,1),
                new Comparator(2, 3),
                new Comparator(1, 2),
                new Comparator(0 ,1)
        );
        return network;
    }

    Network getNetworkSize4AndInvalid() {
        var network = new SimpleNetwork(4);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(0 ,1)
        );
        return network;
    }

    @Test
    void testTestWhenSize3AndValid() {
        var network = getNetworkSize3AndValid();
        var tester = new NetworkBinaryTester();
        var actual = tester.test(network);

        assertEquals(8, actual.count());
        assertEquals(8, actual.correct());
        assertEquals(0, actual.failed());
    }

    @Test
    void testTestWhenSize3AndInValid() {
        var network = getNetworkSize3AndInvalid();
        var tester = new NetworkBinaryTester();
        var actual = tester.test(network);

        assertEquals(8, actual.count());
        assertEquals(7, actual.correct());
        assertEquals(1, actual.failed());
    }

    @Test
    void testTestWhenSize4AndValid() {
        var network = getNetworkSize4AndValid();
        var tester = new NetworkBinaryTester();
        var actual = tester.test(network);

        assertEquals(16, actual.count());
        assertEquals(16, actual.correct());
        assertEquals(0, actual.failed());
    }

    @Test
    void testTestWhenSize4AndInValid() {
        var network = getNetworkSize4AndInvalid();
        var tester = new NetworkBinaryTester();
        var actual = tester.test(network);

        assertEquals(16, actual.count());
        assertEquals(9, actual.correct());
        assertEquals(7, actual.failed());
    }
}