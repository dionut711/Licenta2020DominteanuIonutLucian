package sorting_networks.network;

import org.junit.jupiter.api.Test;
import sorting_networks.Comparator;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SimpleNetworkTest {

    SimpleNetwork getComparatorNetwork() {
        var network = new SimpleNetwork(5);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(0, 3)
        );
        return network;
    }

    SimpleNetwork getSortingNetwork() {
        var network = new SimpleNetwork(5);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(2, 4),
                new Comparator(2, 3),
                new Comparator(0, 3),
                new Comparator(0, 2),
                new Comparator(1, 4),
                new Comparator(1, 3),
                new Comparator(1, 2)
        );
        return network;
    }

    @Test
    void testSortWhenSortingNetwork() {
        SimpleNetwork network = getSortingNetwork();
        List<Integer> actual = Arrays.asList(5, 3, 1, 2, 0);
        List<Integer> expected = Arrays.asList(0, 1, 2, 3, 5);

        network.sort(actual);

        assertIterableEquals(expected, actual, "Sorting network provided wrong output");
    }

    @Test
    void testSortWhenComparatorsNetwork() {
        SimpleNetwork network = getComparatorNetwork();
        List<Integer> actual = Arrays.asList(5, 3, 1, 2, 0);
        List<Integer> expected = Arrays.asList(2, 1, 5, 3, 0);

        network.sort(actual);

        assertIterableEquals(expected, actual, "Comparators network provided wrong output");
    }
}