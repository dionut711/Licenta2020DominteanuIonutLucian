package sorting_networks.trail;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WireTrailTest {
    @Test
    void testWhen2Segments() {
        var trail = new WireTrail(0);
        trail.addSegment(new WireTrailSegment(0, 2, 1));
        trail.addSegment(new WireTrailSegment(1, 3, 2));

        assertEquals(0, trail.getOrigin(-1));
        assertEquals(2, trail.getOrigin(0));
        assertEquals(3, trail.getOrigin(1));
        assertEquals(1, trail.getPrevious(0));
        assertEquals(2, trail.getPrevious(1));
    }

    @Test
    void testWhen3Segments() {
        var trail = new WireTrail(1);
        trail.addSegment(new WireTrailSegment(0, 4, 0));
        trail.addSegment(new WireTrailSegment(1, 5, 2));
        trail.addSegment(new WireTrailSegment(3, 1, 3));

        assertEquals(1, trail.getOrigin(-1));
        assertEquals(4, trail.getOrigin(0));
        assertEquals(5, trail.getOrigin(1));
        assertEquals(5, trail.getOrigin(2));
        assertEquals(0, trail.getPrevious(0));
        assertEquals(2, trail.getPrevious(1));
        assertEquals(1, trail.getPrevious(2));
    }
}