package sorting_networks.factories;

import org.junit.jupiter.api.Test;
import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

import static org.junit.jupiter.api.Assertions.*;

class BubbleSortFactoryTest {

    Network getExpectedForSize5() {
        var network = new SimpleNetwork(5);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(2, 3),
                new Comparator(3, 4),
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(2, 3),
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(0, 1)
        );
        return network;
    }

    @Test
    void testMakeWhenSizeIs5() {
        var actual = (new BubbleSortFactory()).make(5);
        var expected = getExpectedForSize5();

        assertEquals(expected.getSize(), actual.getSize(), "Wrong network size");
        assertIterableEquals(expected.getComparators(), actual.getComparators(), "Wrong comparators");
    }
}