package sorting_networks.depth;

import org.junit.jupiter.api.Test;
import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

import static org.junit.jupiter.api.Assertions.*;

class ParallelDepthsCalculatorTest {

    Network getNetworkWhenBubbleOfSize3() {
        var network = new SimpleNetwork(3);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(0, 1)
        );
        return network;
    }

    Network getNetworkWhenBubbleOfSize4() {
        var network = new SimpleNetwork(4);
        network.getComparators().addAll(
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(2, 3),
                new Comparator(0, 1),
                new Comparator(1, 2),
                new Comparator(0, 1)
        );
        return network;
    }

    @Test
    void getDepthsWhenBubbleOfSize3() {
        var calculator = new ParallelDepthsCalculator();
        var network = getNetworkWhenBubbleOfSize3();
        var comparators = network.getComparators();
        var actual = calculator.getDepths(network);

        assertEquals(actual.get(comparators.get(0)), 0);
        assertEquals(actual.get(comparators.get(1)), 1);
        assertEquals(actual.get(comparators.get(2)), 2);
    }

    @Test
    void getDepthsWhenBubbleOfSize4() {
        var calculator = new ParallelDepthsCalculator();
        var network = getNetworkWhenBubbleOfSize4();
        var comparators = network.getComparators();
        var actual = calculator.getDepths(network);

        assertEquals(actual.get(comparators.get(0)), 0);
        assertEquals(actual.get(comparators.get(1)), 1);
        assertEquals(actual.get(comparators.get(2)), 2);
        assertEquals(actual.get(comparators.get(3)), 2);
        assertEquals(actual.get(comparators.get(4)), 3);
        assertEquals(actual.get(comparators.get(5)), 4);
    }
}