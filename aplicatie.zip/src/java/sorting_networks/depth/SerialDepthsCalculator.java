package sorting_networks.depth;

import sorting_networks.network.Network;

import java.util.HashMap;

public class SerialDepthsCalculator implements DepthsCalculator {
    @Override
    public ComparatorDepths getDepths(Network network) {
        var depths = new MapComparatorDepths(new HashMap<>());

        int currentDepth = 0;

        for (var comparator: network)
        {
            depths.put(comparator, currentDepth);
            currentDepth += 1;
        }

        return depths;
    }
}
