package sorting_networks.depth;

import sorting_networks.network.Network;

public interface DepthsCalculator {
    ComparatorDepths getDepths(Network network);
}
