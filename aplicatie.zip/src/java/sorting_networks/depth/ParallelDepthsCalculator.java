package sorting_networks.depth;

import sorting_networks.Comparator;
import sorting_networks.network.Network;

import java.util.*;

public class ParallelDepthsCalculator implements DepthsCalculator {
    @Override
    public ComparatorDepths getDepths(Network network) {
        var comparators = new ArrayList<ArrayList<Comparator>>();
        comparators.add(new ArrayList<>());

        for (var comparator : network) {
            for (int depth = comparators.size() - 1; depth >= 0; depth--) {
                boolean overlap = comparatorsOverlap(comparators.get(depth), comparator.getX(), comparator.getY());

                if (overlap) {
                    int finalDepth = depth + 1;

                    if (comparators.size() == finalDepth) {
                        comparators.add(new ArrayList<>());
                    }

                    comparators.get(finalDepth).add(comparator);

                    break;
                }
                if (depth == 0) {
                    comparators.get(0).add(comparator);
                }
            }
        }

        var depths = new MapComparatorDepths(new HashMap<>());
        for (int depth = 0; depth < comparators.size(); depth++) {
            var comparatorsStack = comparators.get(depth);
            for (var comparator : comparatorsStack) {
                depths.put(comparator, depth);
            }
        }

        return depths;
    }

    private boolean comparatorsOverlap(List<Comparator> comparators, int x, int y) {
        for (var comparator: comparators) {
            int min1 = Math.min(comparator.getX(), comparator.getY());
            int max1 = Math.max(comparator.getX(), comparator.getY());

            int min2 = Math.min(x, y);
            int max2 = Math.max(x, y);

            if ((min1 <= max2 && max1 >= min2) || (max1 <= max2 && min1 >= min2)) {
                return true;
            }
        }
        return false;
    }
}
