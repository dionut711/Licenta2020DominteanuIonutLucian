package sorting_networks.depth;

import sorting_networks.Comparator;

import java.util.Collection;

public interface ComparatorDepths {
    void put(Comparator comparator, int depth);

    int get(Comparator comparator);

    Collection<Comparator> getComparatorsFor(int depth);

    int getCount();
}
