package sorting_networks.depth;

import sorting_networks.Comparator;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;

public class MapComparatorDepths implements ComparatorDepths{
    private Map<Comparator, Integer> map;

    private int count = 0;

    public MapComparatorDepths(Map<Comparator, Integer> map) {
        this.map = map;
    }

    @Override
    public void put(Comparator comparator, int depth) {
        if (depth + 1 > count) {
            count = depth + 1;
        }
        map.put(comparator, depth);
    }

    @Override
    public int get(Comparator comparator) {
        return map.get(comparator);
    }

    @Override
    public Collection<Comparator> getComparatorsFor(int depth) {
        var comparators = new LinkedList<Comparator>();
        for (var entry: map.entrySet()) {
            if (entry.getValue() == depth) {
                comparators.add(entry.getKey());
            }
        }
        return comparators;
    }

    @Override
    public int getCount() {
        return count;
    }
}
