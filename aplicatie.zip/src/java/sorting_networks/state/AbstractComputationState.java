package sorting_networks.state;

import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ObservableList;
import sorting_networks.Swap;

public class AbstractComputationState implements ComputationState {
    private ObjectProperty<NetworkState> networkState;
    private ListProperty<Swap> swaps;
    private ListProperty<Double> input;
    private ListProperty<Double> output;

    public AbstractComputationState() {
        networkState = new SimpleObjectProperty<>();
        swaps = new SimpleListProperty<>();
        input = new SimpleListProperty<>();
        output = new SimpleListProperty<>();
    }

    @Override
    public void clearComputation() {
        setInput(null);
        setOutput(null);
        setSwaps(null);
    }

    //region Network State
    @Override
    public NetworkState getNetworkState() {
        return networkState.get();
    }

    @Override
    public ObjectProperty<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.set(networkState);
    }
    //endregion

    //region Swaps
    @Override
    public ObservableList<Swap> getSwaps() {
        return swaps.get();
    }

    @Override
    public ListProperty<Swap> swapsProperty() {
        return swaps;
    }

    @Override
    public void setSwaps(ObservableList<Swap> swaps) {
        this.swaps.set(swaps);
    }
    //endregion

    //region Input
    @Override
    public ObservableList<Double> getInput() {
        return input.get();
    }

    @Override
    public ListProperty<Double> inputProperty() {
        return input;
    }

    @Override
    public void setInput(ObservableList<Double> input) {
        this.input.set(input);
    }
    //endregion

    //region Output
    @Override
    public ObservableList<Double> getOutput() {
        return output.get();
    }

    @Override
    public ListProperty<Double> outputProperty() {
        return output;
    }

    @Override
    public void setOutput(ObservableList<Double> output) {
        this.output.set(output);
    }
    //endregion
}
