package sorting_networks.state;

import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import sorting_networks.Comparator;
import sorting_networks.Swap;
import sorting_networks.network.Network;

import java.util.ArrayList;
import java.util.List;

public class SimpleComputationState extends AbstractComputationState {
    private ListChangeListener<Comparator> comparatorsChangeListener = change -> updateSwaps();
    private ListChangeListener<Double> inputChangeListener = change -> updateSwaps();
    private ChangeListener<Network> networkChangeListener = (o, oldNetwork, newNetwork) -> networkChange(oldNetwork, newNetwork);

    public SimpleComputationState() {
        super();

        inputProperty().addListener((o, oldV, newV) -> {
            if (oldV != null) {
                oldV.removeListener(inputChangeListener);
            }
            if (newV != null) {
                newV.addListener(inputChangeListener);
            }
            updateSwaps();
        });

        networkStateProperty().addListener((o, oldState, newState) -> {
            if (oldState != null) {
                oldState.networkProperty().removeListener(networkChangeListener);
            }
            if (newState != null) {
                newState.networkProperty().addListener(networkChangeListener);
            }
        });
    }

    private void networkChange(Network oldValue, Network newValue) {
        inputSizeChange(oldValue, newValue);

        if (oldValue != null) {
            oldValue.getComparators().removeListener(comparatorsChangeListener);
        }
        if (newValue != null) {
            newValue.getComparators().addListener(comparatorsChangeListener);
        }
    }

    private void inputSizeChange(Network oldValue, Network newValue) {
        boolean newSize = oldValue != null && newValue != null && oldValue.getSize() != newValue.getSize();
        boolean init = oldValue == null && newValue != null;

        if (newSize || init) {
            ObservableList<Double> input = FXCollections.observableArrayList();
            for (int i = 0; i < newValue.getSize(); i++) {
                input.add(null);
            }
            setInput(input);
        } else {
            if (newValue == null) {
                setInput(null);
            } else {
                updateSwaps();
            }
        }
    }

    private void updateSwaps() {
        var network = getNetworkState().getNetwork();
        var input = getInput();

        if (validInput(input)) {
            var output = new ArrayList<>(input);
            var swaps = new ArrayList<Swap>();

            network.sort(output, swaps);
            setSwaps(FXCollections.observableArrayList(swaps));
            setOutput(FXCollections.observableArrayList(output));
        } else {
            setOutput(null);
            setSwaps(null);
        }
    }

    private boolean validInput(List<Double> input) {
        if (input != null) {
            for (Double value : input) {
                if (value == null) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }
}
