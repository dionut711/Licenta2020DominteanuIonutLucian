package sorting_networks.state;

import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ObservableList;
import sorting_networks.Swap;
import sorting_networks.depth.ComparatorDepths;
import sorting_networks.depth.DepthsCalculator;
import sorting_networks.network.Network;

public abstract class AbstractNetworkState implements NetworkState {
    private ObjectProperty<Network> network;
    private ObjectProperty<ComparatorDepths> depths;
    private ObjectProperty<DepthsCalculator> depthsCalculator;

    public AbstractNetworkState(DepthsCalculator depthsCalculator) {
        this.network = new SimpleObjectProperty<>();
        this.depths = new SimpleObjectProperty<>();
        this.depthsCalculator = new SimpleObjectProperty<>();

        setDepthsCalculator(depthsCalculator);
    }

    //region Network
    @Override
    public Network getNetwork() {
        return network.getValue();
    }

    @Override
    public Property<Network> networkProperty() {
        return network;
    }

    @Override
    public void setNetwork(Network network) {
        this.network.setValue(network);
    }
    //endregion

    //region Depths
    @Override
    public ComparatorDepths getDepths() {
        return depths.getValue();
    }

    @Override
    public Property<ComparatorDepths> depthsProperty() {
        return depths;
    }

    @Override
    public void setDepths(ComparatorDepths depths) {
        this.depths.setValue(depths);
    }
    //endregion

    //region DepthsCalculator
    @Override
    public DepthsCalculator getDepthsCalculator() {
        return depthsCalculator.getValue();
    }

    @Override
    public Property<DepthsCalculator> depthsCalculatorProperty() {
        return depthsCalculator;
    }

    @Override
    public void setDepthsCalculator(DepthsCalculator depthsCalculator) {
        this.depthsCalculator.setValue(depthsCalculator);
    }
    //endregion
}
