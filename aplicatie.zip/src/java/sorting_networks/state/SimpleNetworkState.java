package sorting_networks.state;

import javafx.collections.ListChangeListener;
import sorting_networks.Comparator;
import sorting_networks.depth.DepthsCalculator;

public class SimpleNetworkState extends AbstractNetworkState {
    public SimpleNetworkState(DepthsCalculator depthsCalculator) {
        super(depthsCalculator);

        networkProperty().addListener((observableValue, oldValue, newValue) -> {
            if (oldValue != null) {
                oldValue.getComparators().removeListener(this::onComparatorsChange);
            }
            if (newValue != null) {
                newValue.getComparators().addListener(this::onComparatorsChange);
            }
            updateDepths();
        });

        depthsCalculatorProperty().addListener((observableValue, oldValue, newValue) -> {
            var network = getNetwork();
            if (network != null) {
                setDepths(newValue.getDepths(network));
            }
        });
    }

    private void onComparatorsChange(ListChangeListener.Change<? extends Comparator> change) {
        updateDepths();
    }

    private void updateDepths() {
        var network = getNetwork();
        var calculator = getDepthsCalculator();

        if (network != null && calculator != null) {
            setDepths(calculator.getDepths(network));
        } else {
            setDepths(null);
        }
    }
}
