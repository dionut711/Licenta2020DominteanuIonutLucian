package sorting_networks.state;

import javafx.beans.property.Property;
import sorting_networks.depth.ComparatorDepths;
import sorting_networks.depth.DepthsCalculator;
import sorting_networks.network.Network;

public interface NetworkState {
    //region Network
    Network getNetwork();

    Property<Network> networkProperty();

    void setNetwork(Network network);
    //endregion

    //region Depths
    ComparatorDepths getDepths();

    Property<ComparatorDepths> depthsProperty();

    void setDepths(ComparatorDepths depths);
    //endregion

    //region DepthsCalculator
    DepthsCalculator getDepthsCalculator();

    Property<DepthsCalculator> depthsCalculatorProperty();

    void setDepthsCalculator(DepthsCalculator depthsCalculator);
    //endregion
}
