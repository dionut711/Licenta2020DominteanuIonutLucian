package sorting_networks.state;

import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import sorting_networks.Swap;

public interface ComputationState {
    void clearComputation();

    //region Network State
    NetworkState getNetworkState();

    ObjectProperty<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    //region Swaps
    ObservableList<Swap> getSwaps();

    ListProperty<Swap> swapsProperty();

    void setSwaps(ObservableList<Swap> swaps);
    //endregion

    //region Input
    ObservableList<Double> getInput();

    ListProperty<Double> inputProperty();

    void setInput(ObservableList<Double> input);
    //endregion

    //region Output
    ObservableList<Double> getOutput();

    ListProperty<Double> outputProperty();

    void setOutput(ObservableList<Double> output);
    //endregion
}
