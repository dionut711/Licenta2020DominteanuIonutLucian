package sorting_networks;

public class Swap {
    private Comparator comparator;
    private Comparable inputA;
    private Comparable inputB;

    public Swap(Comparator comparator, Comparable inputA, Comparable inputB) {
        this.comparator = comparator;
        this.inputA = inputA;
        this.inputB = inputB;
    }

    public Comparator getComparator() {
        return comparator;
    }

    public void setComparator(Comparator comparator) {
        this.comparator = comparator;
    }

    public Comparable getInputA() {
        return inputA;
    }

    public void setInputA(Comparable inputA) {
        this.inputA = inputA;
    }

    public Comparable getInputB() {
        return inputB;
    }

    public void setInputB(Comparable inputB) {
        this.inputB = inputB;
    }
}
