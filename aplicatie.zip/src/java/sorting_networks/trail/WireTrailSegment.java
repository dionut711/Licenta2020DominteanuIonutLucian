package sorting_networks.trail;

public class WireTrailSegment {
    private int depth;
    private int origin;
    private int previous;

    public WireTrailSegment(int depth, int origin, int previous) {
        this.depth = depth;
        this.origin = origin;
        this.previous = previous;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public int getOrigin() {
        return origin;
    }

    public void setOrigin(int origin) {
        this.origin = origin;
    }

    public int getPrevious() {
        return previous;
    }

    public void setPrevious(int previous) {
        this.previous = previous;
    }
}
