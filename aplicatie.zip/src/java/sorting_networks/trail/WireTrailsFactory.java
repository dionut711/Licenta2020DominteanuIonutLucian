package sorting_networks.trail;

import sorting_networks.Swap;
import sorting_networks.depth.ComparatorDepths;

import java.util.*;

public abstract class WireTrailsFactory {
    public static List<WireTrail> makeListFromSwaps(int size, ComparatorDepths depths, List<Swap> swaps) {
        List<WireTrail> wireTrails = new ArrayList<>(size);

        for (int wire = 0; wire < size; wire++) {
            wireTrails.add(new WireTrail(wire));
        }

        for (var swap : swaps) {
            var comparator = swap.getComparator();
            var x = comparator.getX();
            var y = comparator.getY();
            var depth = depths.get(comparator);

            add(wireTrails, depth, x, y);
            add(wireTrails, depth, y, x);
        }

        return wireTrails;
    }

    private static void add(List<WireTrail> wireTrails, int depth, int current, int previous) {
        var origin = wireTrails.get(previous).getOrigin(depth - 1);
        wireTrails.get(current).addSegment(new WireTrailSegment(depth, origin, previous));
    }
}
