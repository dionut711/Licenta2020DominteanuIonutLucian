package sorting_networks.trail;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class WireTrail {
    private int wire;

    private LinkedList<WireTrailSegment> segments = new LinkedList<>();

    public WireTrail(int wire) {
        this.wire = wire;
    }

    public int getOrigin(int depth) {
        var iterator = segments.descendingIterator();
        while (iterator.hasNext()) {
            var segment = iterator.next();
            if (segment.getDepth() <= depth)
                return segment.getOrigin();
        }
        return wire;
    }

    public int getPrevious(int depth) {
        var iterator = segments.descendingIterator();
        while (iterator.hasNext()) {
            var segment = iterator.next();
            if (segment.getDepth() == depth) {
                return segment.getPrevious();
            } else if (segment.getDepth() < depth) {
                return wire;
            }
        }
        return wire;
    }

    public List<WireTrailSegment> getSegments() {
        return new LinkedList<>(segments);
    }

    public void addSegment(WireTrailSegment segment) {
        int depth = segment.getDepth();
        var previous = segments.peek();

        if (previous == null || previous.getDepth() < depth) {
            segments.add(segment);
        }
    }

    @Override
    public String toString() {
        var text = wire + ": ";
        var previous = wire;
        for (var segment : segments) {
            text += String.format("(o: %d, p: %d, d: %d) ", segment.getOrigin(), segment.getPrevious(), segment.getDepth());
            previous = segment.getPrevious();
        }
        return text;
    }
}
