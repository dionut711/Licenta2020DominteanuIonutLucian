package sorting_networks.test;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TestResultRow {
    private StringProperty input = new SimpleStringProperty();
    private StringProperty output = new SimpleStringProperty();
    private BooleanProperty passed = new SimpleBooleanProperty();

    public TestResultRow(String input, String output, boolean passed) {
        setInput(input);
        setOutput(output);
        setPassed(passed);
    }

    public String getInput() {
        return input.get();
    }

    public StringProperty inputProperty() {
        return input;
    }

    public void setInput(String input) {
        this.input.set(input);
    }

    public String getOutput() {
        return output.get();
    }

    public StringProperty outputProperty() {
        return output;
    }

    public void setOutput(String output) {
        this.output.set(output);
    }

    public boolean isPassed() {
        return passed.get();
    }

    public BooleanProperty passedProperty() {
        return passed;
    }

    public void setPassed(boolean passed) {
        this.passed.set(passed);
    }
}
