package sorting_networks.test;

import java.util.LinkedList;
import java.util.List;

public class TestResult {
    private List<TestResultRow> rows = new LinkedList<>();
    private long time = 0;

    public int count() {
        return rows.size();
    }

    public int correct() {
        int count = 0;
        for (var row: rows)
            if (row.isPassed()) count++;
        return count;
    }

    public int failed() {
        return count() - correct();
    }

    public List<TestResultRow> getRows() {
        return new LinkedList<>(rows);
    }

    public void addRow(TestResultRow row, double time) {
        this.time += time;
        this.rows.add(row);
    }

    public long getTime() {
        return time;
    }
}
