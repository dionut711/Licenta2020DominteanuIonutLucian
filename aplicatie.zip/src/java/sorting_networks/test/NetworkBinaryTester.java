package sorting_networks.test;

import sorting_networks.network.Network;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NetworkBinaryTester {
    public TestResult test(Network network) {
        int size = network.getSize();
        int count = (int) Math.pow(2, size);

        var testResult = new TestResult();

        for (int inputByte = 0; inputByte < count; inputByte++) {
            var input = binaryList(inputByte, size);

            var inputString = Arrays.toString(input.toArray());

            long start = System.nanoTime();
            network.sort(input);
            long duration = System.nanoTime() - start;

            var outputString = Arrays.toString(input.toArray());
            boolean passed = isSorted(input);

            testResult.addRow(new TestResultRow(inputString, outputString, passed), duration);
        }

        return testResult;
    }

    private List<Integer> binaryList(int x, int size) {
        List<Integer> input = new ArrayList<>();
        for (int i = size - 1; i >= 0; i--) {
            input.add(x % 2);
            x >>= 1;
        }
        return input;
    }

    private boolean isSorted(List<Integer> list) {
        for (int i = 0; i < list.size() - 1; i++) {
            if (list.get(i).compareTo(list.get(i + 1)) > 0) {
                return false;
            }
        }
        return true;
    }
}
