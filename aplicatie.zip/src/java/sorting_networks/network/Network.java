package sorting_networks.network;

import javafx.collections.ObservableList;
import sorting_networks.Comparator;
import sorting_networks.Swap;

import java.util.List;

public interface Network extends Iterable<Comparator> {
    ObservableList<Comparator> getComparators();

    int getSize();

    <T extends Comparable> void sort(List<T> list);

    <T extends Comparable> void sort(List<T> list, List<Swap> swaps);

    Network clone();
}
