package sorting_networks.network;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import sorting_networks.Comparator;
import sorting_networks.Swap;

import java.util.*;

public class SimpleNetwork implements Network {
    private ObservableList<Comparator> comparators;

    private int size;

    public SimpleNetwork(int size) {
        this.size = size;

        comparators = FXCollections.observableArrayList();
    }

    @Override
    public ObservableList<Comparator> getComparators() {
        return comparators;
    }

    @Override
    public Iterator<sorting_networks.Comparator> iterator() {
        return comparators.iterator();
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public <T extends Comparable> void sort(List<T> list) {
        sort(list, null);
    }

    @Override
    public <T extends Comparable> void sort(List<T> list, List<Swap> swaps) {
        for (Comparator comparator : comparators) {
            T a = list.get(comparator.getX());
            T b = list.get(comparator.getY());

            if (a.compareTo(b) > 0) {
                list.set(comparator.getX(), b);
                list.set(comparator.getY(), a);
                if (swaps != null) {
                    swaps.add(new Swap(comparator, b, a));
                }
            }
        }
    }

    @Override
    public Network clone() {
        var network = new SimpleNetwork(size);
        for (var comparator: comparators) {
            var x = comparator.getX();
            var y = comparator.getY();
            network.getComparators().add(new Comparator(x, y));
        }
        return network;
    }
}
