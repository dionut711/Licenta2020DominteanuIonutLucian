package sorting_networks.factories;

import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

import java.util.ArrayList;

public class BubbleSortFactory implements NetworkFactory {
    @Override
    public Network make(int size) {
        Network network = new SimpleNetwork(size);
        var comparators = network.getComparators();

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                comparators.add(new Comparator(j, j + 1));
            }
        }

        return network;
    }
}
