package sorting_networks.factories;

import sorting_networks.network.Network;

public interface MergeNetworkFactory {
    Network make(Network network, int m, int n);
}
