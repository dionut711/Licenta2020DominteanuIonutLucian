package sorting_networks.factories;

import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

public class OddEvenSortFactory implements NetworkFactory, MergeNetworkFactory {
    @Override
    public Network make(int size) {
        Network network = new SimpleNetwork(size);
        network.getComparators().addAll(sortHalves(size));
        return network;
    }

    @Override
    public Network make(Network network, int m, int n) {
        var newNetwork = network.clone();
        newNetwork.getComparators().addAll(merge(m, n));
        return newNetwork;
    }

    private List<Comparator> merge(int m, int n) {
        List<Comparator> comparators = new Stack<>();

        if (m + n <= 2) {
            if (m == 1 && n == 1) {
                comparators.add(new Comparator(0, 1));
            }
            return comparators;
        }

        var v = merge((int)Math.ceil(m / 2.0), (int)Math.ceil(n / 2.0));
        var w = merge((int)Math.floor(m / 2.0), (int)Math.floor(n / 2.0));

        comparators.addAll(evenfy(v, m, n));
        comparators.addAll(oddify(w, m, n));
        comparators.addAll(exchange(m, n));

        return comparators;
    }

    private List<Comparator> sort(int m, int n) {
        List<Comparator> stack = new Stack<>();

        if (m + n <= 2) {
            if (m + n == 2) {
                stack.add(new Comparator(0, 1));
            }
            return stack;
        }

        if (m == 0) {
            stack.addAll(sortHalves(n));
        } else if (n == 0) {
            stack.addAll(sortHalves(n));
        } else {
            stack.addAll(sortHalves(m));
            stack.addAll(offset(sortHalves(n), m));
            stack.addAll(merge(m, n));
        }

        return stack;
    }

    private List<Comparator> sortHalves(int size) {
        int m = (int)Math.ceil(size / 2.0);
        int n = (int)Math.floor(size / 2.0);
        return sort(m, n);
    }

    private List<Comparator> offset(List<Comparator> comparators, int value) {
        for (var comparator: comparators) {
            comparator.setX(comparator.getX() + value);
            comparator.setY(comparator.getY() + value);
        }
        return comparators;
    }

    private List<Comparator> evenfy(List<Comparator> comparators, int m, int n) {
        List<Comparator> newComparators = new Stack<>();
        Map<Integer, Integer> map = new HashMap<>();
        int counter = 0;

        for (int i = 0; i < m + n; i++) {
            if ((i < m && i % 2 == 0) || (i >= m && (i - m) % 2 == 0)) {
                map.put(counter, i);
                counter += 1;
            }
        }

        for (var comparator: comparators) {
            int x = map.get(comparator.getX());
            int y = map.get(comparator.getY());
            newComparators.add(new Comparator(x, y));
        }
        return newComparators;
    }

    private List<Comparator> oddify(List<Comparator> comparators, int m, int n) {
        List<Comparator> newComparators = new Stack<>();
        Map<Integer, Integer> map = new HashMap<>();
        int counter = 0;

        for (int i = 0; i < m + n; i++) {
            if ((i < m && i % 2 == 1) || (i >= m && (i - m) % 2 == 1)) {
                map.put(counter, i);
                counter += 1;
            }
        }

        for (var comparator: comparators) {
            int x = map.get(comparator.getX());
            int y = map.get(comparator.getY());
            newComparators.add(new Comparator(x, y));
        }
        return newComparators;
    }

    private List<Comparator> exchange(int m, int n) {
        List<Comparator> comparators = new Stack<>();

        for (int i = 1; i < m + n - 1; i += 2) {
            comparators.add(new Comparator(i, i + 1));
        }

        return comparators;
    }
}
