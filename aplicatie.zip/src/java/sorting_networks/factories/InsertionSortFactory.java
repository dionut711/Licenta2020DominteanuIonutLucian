package sorting_networks.factories;

import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

public class InsertionSortFactory implements NetworkFactory {
    @Override
    public Network make(int size) {
        Network network = new SimpleNetwork(size);
        var comparators = network.getComparators();

        for (int i = 0; i < size - 1; i++) {
            for (int j = i; j >= 0; j--) {
                comparators.add(new Comparator(j, j + 1));
            }
        }

        return network;
    }
}
