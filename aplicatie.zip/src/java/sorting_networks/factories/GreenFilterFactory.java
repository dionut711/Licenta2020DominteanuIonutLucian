package sorting_networks.factories;

import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

import java.util.LinkedList;
import java.util.List;

public class GreenFilterFactory implements FilterNetworkFactory {
    @Override
    public List<Comparator> comparators(int size) {
        var comparators = new LinkedList<Comparator>();

        for (int step = 1; step <= size / 2; step *= 2) {
            for (int offset = 0; offset < step; offset += 1) {
                for (int x = offset; x < size - step; x += step * 2) {
                    int y = x + step;
                    comparators.add(new Comparator(x, y));
                }
            }
        }

        return comparators;
    }

    @Override
    public Network append(Network network) {
        var comparators = comparators(network.getSize());
        network.getComparators().addAll(comparators);
        return network;
    }

    @Override
    public Network make(int size) {
        var network = new SimpleNetwork(size);
        network.getComparators().addAll(comparators(size));
        return network;
    }
}
