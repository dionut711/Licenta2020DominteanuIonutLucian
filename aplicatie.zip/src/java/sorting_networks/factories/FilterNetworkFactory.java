package sorting_networks.factories;

import sorting_networks.Comparator;
import sorting_networks.network.Network;

import java.util.List;

public interface FilterNetworkFactory extends NetworkFactory {
    List<Comparator> comparators(int size);

    Network append(Network network);
}
