package sorting_networks.factories;

import sorting_networks.network.Network;

public interface NetworkFactory {
    Network make(int size);
}
