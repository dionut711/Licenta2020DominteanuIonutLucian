package drawing.colors;

import javafx.scene.paint.Color;

import java.util.List;

public interface WiresColorPicker {
    Color getColor(int networkSize, int index);

    List<Color> getColors(int networkSize);
}
