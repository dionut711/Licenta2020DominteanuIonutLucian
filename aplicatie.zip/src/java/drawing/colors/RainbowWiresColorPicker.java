package drawing.colors;

import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;

public class RainbowWiresColorPicker implements  WiresColorPicker {
    @Override
    public Color getColor(int networkSize, int index) {
        double ratio = index / (networkSize - 1.0) * 5;

        int r = 0, b = 0, g = 0;
        if (ratio >= 0 && ratio <= 1) { // orange -> yellow
            r = 255;
            g = lerp(ratio);
            b = 0;
        } else if (ratio >= 1 && ratio <= 2) { // yellow -> green
            r = 255 - lerp(ratio - 1);
            g = 255;
            b = 0;
        } else if (ratio >= 2 && ratio <= 3) { // green -> cyan
            r = 0;
            g = 255;
            b = lerp(ratio - 2);
        } else if (ratio >= 3 && ratio <= 4) { // cyan -> blue
            r = 0;
            g = 255 - lerp(ratio - 3);
            b = 255;
        } else if (ratio >= 4 && ratio <= 5) { // blue -> purple
            r = lerp(ratio - 4);
            g = 0;
            b = 255;
        } else { // purple -> red
            r = 255;
            g = 0;
            b = 255 - lerp(ratio - 5);
        }

        return Color.rgb(r, g, b);
    }

    @Override
    public List<Color> getColors(int networkSize) {
        var colors = new ArrayList<Color>();

        for (int i = 0; i < networkSize; i++)
        {
            colors.add(getColor(networkSize, i));
        }

        return colors;
    }

    private int lerp(double t)
    {
        return (int)(255 * (1 * t));
    }
}
