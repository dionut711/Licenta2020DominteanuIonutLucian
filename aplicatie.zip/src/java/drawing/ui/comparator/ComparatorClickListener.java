package drawing.ui.comparator;

public interface ComparatorClickListener {
    void onClick(ComparatorClickEvent event);
}
