package drawing.ui.comparator;

import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Shape;
import sorting_networks.Comparator;

public class ShapeComparatorUI extends AbstractComparatorUI {
    private Shape connector;
    private Shape anchor1;
    private Shape anchor2;

    public ShapeComparatorUI(Comparator comparator, Shape connector, Shape anchor1, Shape anchor2) {
        super(comparator);
        this.connector = connector;
        this.anchor1 = anchor1;
        this.anchor2 = anchor2;

        connector.addEventFilter(MouseEvent.MOUSE_PRESSED, (event) -> this.click());
        anchor1.addEventFilter(MouseEvent.MOUSE_PRESSED, (event) -> this.click());
        anchor2.addEventFilter(MouseEvent.MOUSE_PRESSED, (event) -> this.click());
    }

    public Shape getConnector() {
        return connector;
    }

    public void setConnector(Shape connector) {
        this.connector = connector;
    }

    public Shape getAnchor1() {
        return anchor1;
    }

    public void setAnchor1(Shape anchor1) {
        this.anchor1 = anchor1;
    }

    public Shape getAnchor2() {
        return anchor2;
    }

    public void setAnchor2(Shape anchor2) {
        this.anchor2 = anchor2;
    }
}
