package drawing.ui.comparator;

public interface ComparatorClickEvent {
    ComparatorUI getComparatorUI();
}
