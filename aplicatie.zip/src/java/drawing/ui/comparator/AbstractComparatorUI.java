package drawing.ui.comparator;

import sorting_networks.Comparator;

import java.util.List;
import java.util.Stack;

public abstract class AbstractComparatorUI implements ComparatorUI {
    private Comparator comparator;

    private List<ComparatorClickListener> listeners;

    public AbstractComparatorUI(Comparator comparator) {
        this.comparator = comparator;

        listeners = new Stack<>();
    }

    @Override
    public void addClickListener(ComparatorClickListener listener) {
        listeners.add(listener);
    }

    @Override
    public void removeClickListener(ComparatorClickListener listener) {
        listeners.remove(listener);
    }

    @Override
    public void click() {
        for (var listener : listeners) {
            listener.onClick(() -> this);
        }
    }

    @Override
    public Comparator getComparator() {
        return comparator;
    }

    @Override
    public void setComparator(Comparator comparator) {
        this.comparator = comparator;
    }
}
