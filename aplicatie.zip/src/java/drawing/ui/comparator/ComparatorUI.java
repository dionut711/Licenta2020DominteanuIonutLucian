package drawing.ui.comparator;

import sorting_networks.Comparator;

public interface ComparatorUI {
    void addClickListener(ComparatorClickListener listener);

    void removeClickListener(ComparatorClickListener listener);

    void click();

    Comparator getComparator();

    void setComparator(Comparator comparator);
}
