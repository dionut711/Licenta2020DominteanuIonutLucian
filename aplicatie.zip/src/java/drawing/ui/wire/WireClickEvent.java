package drawing.ui.wire;

public interface WireClickEvent {
    WireUI getWireUI();
}
