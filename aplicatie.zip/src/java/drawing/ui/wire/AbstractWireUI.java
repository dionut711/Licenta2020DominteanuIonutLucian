package drawing.ui.wire;

import java.util.List;
import java.util.Stack;

public abstract class AbstractWireUI implements WireUI {
    private int wire;

    private List<WireClickListener> listeners;

    public AbstractWireUI(int wire) {
        this.wire = wire;

        listeners = new Stack<>();
    }

    @Override
    public void addClickListener(WireClickListener listener) {
        listeners.add(listener);
    }

    @Override
    public void removeClickListener(WireClickListener listener) {
        listeners.remove(listener);
    }

    @Override
    public void click() {
        for (var listener: listeners) {
            listener.onClick(() -> this);
        }
    }

    @Override
    public int getWire() {
        return wire;
    }

    @Override
    public void setWire(int wire) {
        this.wire = wire;
    }
}
