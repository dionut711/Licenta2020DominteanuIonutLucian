package drawing.ui.wire;

public interface WireUI {
    void addClickListener(WireClickListener listener);

    void removeClickListener(WireClickListener listener);

    void click();

    int getWire();

    void setWire(int wire);
}
