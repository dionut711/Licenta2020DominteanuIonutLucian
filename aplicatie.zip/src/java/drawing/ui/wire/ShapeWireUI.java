package drawing.ui.wire;

import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Shape;

public class ShapeWireUI extends AbstractWireUI {
    private int wire;
    private Shape shape;

    public ShapeWireUI(int wire, Shape shape) {
        super(wire);
        this.shape = shape;

        shape.addEventFilter(MouseEvent.MOUSE_PRESSED, (event) -> this.click());
    }

    public Shape getShape() {
        return shape;
    }

    public void setShape(Shape shape) {
        this.shape = shape;
    }
}
