package drawing.ui.wire;

public interface WireClickListener {
    void onClick(WireClickEvent event);
}
