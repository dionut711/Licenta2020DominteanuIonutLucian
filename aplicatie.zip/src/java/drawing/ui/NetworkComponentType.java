package drawing.ui;

public enum NetworkComponentType {
    WIRE,
    COMPARATOR_ANCHOR,
    COMPARATOR_CONNECTOR
}
