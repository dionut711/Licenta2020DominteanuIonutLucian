package drawing.ui.network;

import drawing.ui.comparator.ComparatorUI;
import drawing.ui.wire.WireUI;
import javafx.collections.ObservableList;

import java.util.List;

public interface NetworkUI {
    ObservableList<WireUI> getWires();

    ObservableList<ComparatorUI> getComparators();

    void addClickListener(NetworkClickListener listener);

    void removeClickListener(NetworkClickListener listener);
}
