package drawing.ui.network;

import drawing.ui.comparator.ComparatorClickEvent;
import drawing.ui.comparator.ComparatorUI;
import drawing.ui.wire.WireClickEvent;
import drawing.ui.wire.WireUI;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.layout.Pane;

public class ShapesNetworkUI extends AbstractNetworkUI {
    private Pane pane;

    public ShapesNetworkUI(Pane pane) {
        super();
        this.pane = pane;
    }
}
