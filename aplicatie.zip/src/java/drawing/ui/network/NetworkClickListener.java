package drawing.ui.network;

public interface NetworkClickListener {
    void onClick(NetworkClickEvent event);
}
