package drawing.ui.network;

import drawing.ui.NetworkComponentType;
import drawing.ui.comparator.ComparatorClickEvent;
import drawing.ui.wire.WireClickEvent;

public class SimpleNetworkClickEvent implements NetworkClickEvent {
    private WireClickEvent wireEvent;
    private ComparatorClickEvent comparatorEvent;
    private NetworkComponentType componentType;

    public SimpleNetworkClickEvent(WireClickEvent wireEvent) {
        this.wireEvent = wireEvent;
        componentType = NetworkComponentType.WIRE;
    }

    public SimpleNetworkClickEvent(ComparatorClickEvent comparatorEvent) {
        this.comparatorEvent = comparatorEvent;
        componentType = NetworkComponentType.COMPARATOR_CONNECTOR;
    }

    @Override
    public WireClickEvent getWireEvent() {
        return wireEvent;
    }

    @Override
    public ComparatorClickEvent getComparatorEvent() {
        return comparatorEvent;
    }

    @Override
    public NetworkComponentType getComponentType() {
        return componentType;
    }
}
