package drawing.ui.network;

import drawing.ui.comparator.ComparatorClickEvent;
import drawing.ui.comparator.ComparatorUI;
import drawing.ui.wire.WireClickEvent;
import drawing.ui.wire.WireUI;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractNetworkUI implements NetworkUI {
    private int networkSize;
    private int networkDepth;

    private ObservableList<WireUI> wires = FXCollections.observableArrayList();
    private ObservableList<ComparatorUI> comparators = FXCollections.observableArrayList();

    private List<NetworkClickListener> clickListeners = new ArrayList<>();

    public AbstractNetworkUI() {
        wires.addListener((ListChangeListener<WireUI>) this::attachWireListeners);
        comparators.addListener((ListChangeListener<ComparatorUI>) this::attachComparatorListeners);
    }

    public int getNetworkSize() {
        return networkSize;
    }

    public void setNetworkSize(int networkSize) {
        this.networkSize = networkSize;
    }

    public int getNetworkDepth() {
        return networkDepth;
    }

    public void setNetworkDepth(int networkDepth) {
        this.networkDepth = networkDepth;
    }

    @Override
    public ObservableList<WireUI> getWires() {
        return wires;
    }

    @Override
    public ObservableList<ComparatorUI> getComparators() {
        return comparators;
    }

    @Override
    public void addClickListener(NetworkClickListener listener) {
        clickListeners.add(listener);
    }

    @Override
    public void removeClickListener(NetworkClickListener listener) {
        clickListeners.remove(listener);
    }

    protected void raiseOnClickEvent(NetworkClickEvent event) {
        for (var listener : clickListeners) {
            listener.onClick(event);
        }
    }

    private <T extends WireUI> void attachWireListeners(ListChangeListener.Change<T> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                for (var wire: change.getAddedSubList()) {
                    wire.addClickListener(this::raiseWireOnClick);
                }
            }
            else if (change.wasRemoved()) {
                for (var wire: change.getRemoved()) {
                    wire.removeClickListener(this::raiseWireOnClick);
                }
            }
        }
    }

    private <T extends ComparatorUI> void attachComparatorListeners(ListChangeListener.Change<T> change) {
        while (change.next()) {
            if (change.wasAdded()) {
                for (var comparator : change.getAddedSubList()) {
                    comparator.addClickListener(this::raiseComparatorOnClick);
                }
            }
            else if (change.wasRemoved()) {
                for (var comparator : change.getRemoved()) {
                    comparator.removeClickListener(this::raiseComparatorOnClick);
                }
            }
        }


    }

    private void raiseWireOnClick(WireClickEvent wireClickEvent) {
        var event = new SimpleNetworkClickEvent(wireClickEvent);
        for (var listener : clickListeners) {
            listener.onClick(event);
        }
    }

    private void raiseComparatorOnClick(ComparatorClickEvent comparatorClickEvent) {
        var event = new SimpleNetworkClickEvent(comparatorClickEvent);
        for (var listener : clickListeners) {
            listener.onClick(event);
        }
    }
}
