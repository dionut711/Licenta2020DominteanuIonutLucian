package drawing.ui.network;

import drawing.ui.NetworkComponentType;
import drawing.ui.comparator.ComparatorClickEvent;
import drawing.ui.wire.WireClickEvent;

public interface NetworkClickEvent {
    WireClickEvent getWireEvent();

    ComparatorClickEvent getComparatorEvent();

    NetworkComponentType getComponentType();
}
