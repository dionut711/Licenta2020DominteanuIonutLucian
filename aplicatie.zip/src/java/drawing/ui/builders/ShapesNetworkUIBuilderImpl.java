package drawing.ui.builders;

import drawing.ui.comparator.ComparatorUI;
import drawing.ui.comparator.ShapeComparatorUI;
import drawing.ui.network.ShapesNetworkUI;
import drawing.ui.wire.ShapeWireUI;
import drawing.ui.wire.WireUI;
import javafx.scene.shape.Shape;
import sorting_networks.Comparator;

public class ShapesNetworkUIBuilderImpl implements ShapesNetworkUIBuilder {
    @Override
    public WireUI makeWire(int wire, Shape shape) {
        return new ShapeWireUI(wire, shape);
    }

    @Override
    public ComparatorUI makeComparator(Comparator comparator, Shape connector, Shape anchor1, Shape anchor2) {
        return new ShapeComparatorUI(comparator, connector, anchor1, anchor2);
    }
}
