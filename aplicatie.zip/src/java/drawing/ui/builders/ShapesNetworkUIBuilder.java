package drawing.ui.builders;

import drawing.ui.comparator.ComparatorUI;
import drawing.ui.wire.WireUI;
import javafx.scene.shape.Shape;
import sorting_networks.Comparator;

public interface ShapesNetworkUIBuilder {
    WireUI makeWire(int wire, Shape shape);

    ComparatorUI makeComparator(Comparator comparator, Shape connector, Shape anchor1, Shape anchor2);
}
