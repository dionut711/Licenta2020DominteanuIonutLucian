package drawing.network;
import drawing.colors.WiresColorPicker;
import drawing.ui.network.NetworkUI;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.geometry.Insets;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import sorting_networks.depth.ComparatorDepths;
import sorting_networks.network.Network;
import sorting_networks.Swap;
import sorting_networks.depth.DepthsCalculator;
import sorting_networks.trail.WireTrail;

import java.util.List;

public interface SortingNetworkDrawer {
    void clear();


    void drawNetwork(Network network, ComparatorDepths depths);

    void drawComputation(Network network, ComparatorDepths depths, List<? extends Comparable> input);


    void drawWires(Network network);

    void drawComparators(Network network, ComparatorDepths depths);


    void drawTrailSegment(int networkSize, int networkDepth, int wire, int fromDepth, int toDepth, Paint paint);

    void drawComparatorPass(int networkSize, int networkDepth, int wire, int depth, Paint paint);

    void drawComparatorSwap(int networkSize, int networkDepth, int fromWire, int toWire, int depth, Paint paint);


    void drawTrailsForDepth(List<WireTrail> wireTrails, List<Color> colors, int networkSize, int networkDepth, int depth);

    //region Measurements
    double getHeight();

    double getWidth();

    //region Padding
    Insets getPadding();

    Property<Insets> paddingProperty();

    void setPadding(Insets padding);

    double getVerticalPadding();

    double getHorizontalPadding();
    //endregion

    //region Components
    double getWireWidth();

    void setWireWidth(double wireWidth);

    double getComparatorWidth();

    void setComparatorWidth(double comparatorWidth);

    double getComparatorRadius();

    void setComparatorRadius(double comparatorRadius);

    double getTrailWidth();

    void setTrailWidth(double trailWidth);

    double getWireContainerWidth(int size);

    double getComparatorContainerWidth(int size);
    //endregion
    //endregion

    //region Colors
    WiresColorPicker getWiresColorPicker();

    void setWiresColorPicker(WiresColorPicker wiresColorPicker);

    Color getDefaultWireColor();

    void setDefaultWireColor(Color defaultWireColor);

    Color getDefaultComparatorColor();

    void setDefaultComparatorColor(Color defaultComparatorColor);
    //endregion

    //region UI
    NetworkUI getNetworkUI();

    ObjectProperty<NetworkUI> networkUIProperty();

    void setNetworkUI(NetworkUI networkUI);
    //endregion

    //region Show Values
    boolean getShowValues();

    BooleanProperty showValuesProperty();

    void setShowValues(boolean showValues);
    //endregion
}
