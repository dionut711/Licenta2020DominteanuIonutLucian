package drawing.network;

import drawing.colors.WiresColorPicker;
import drawing.ui.network.NetworkUI;
import javafx.beans.property.*;
import javafx.geometry.Insets;
import javafx.scene.paint.Color;
import sorting_networks.Swap;
import sorting_networks.network.Network;
import sorting_networks.depth.ComparatorDepths;
import sorting_networks.trail.WireTrail;
import sorting_networks.trail.WireTrailsFactory;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractNetworkDrawer implements SortingNetworkDrawer {
    public AbstractNetworkDrawer(WiresColorPicker wiresColorPicker) {
        this.wiresColorPicker = wiresColorPicker;
    }

    //region Measurements
    private double wireWidth = 2;
    private double comparatorWidth = 3;
    private double comparatorRadius = 8;
    private double trailWidth = 4;

    public double getWireWidth() {
        return wireWidth;
    }

    public void setWireWidth(double wireWidth) {
        this.wireWidth = wireWidth;
    }

    public double getComparatorWidth() {
        return comparatorWidth;
    }

    public void setComparatorWidth(double comparatorWidth) {
        this.comparatorWidth = comparatorWidth;
    }

    public double getComparatorRadius() {
        return comparatorRadius;
    }

    public void setComparatorRadius(double comparatorRadius) {
        this.comparatorRadius = comparatorRadius;
    }

    @Override
    public double getTrailWidth() {
        return trailWidth;
    }

    @Override
    public void setTrailWidth(double trailWidth) {
        this.trailWidth = trailWidth;
    }

    public double getWireContainerWidth(int size) {
        return getHeight() / size;
    }

    public double getComparatorContainerWidth(int networkDepth) {
        return getWidth() / (networkDepth + 1);
    }

    //region Padding
    protected Property<Insets> padding = new SimpleObjectProperty<>(new Insets(0));

    public Insets getPadding() {
        return padding.getValue();
    }

    public Property<Insets> paddingProperty() {
        return padding;
    }

    public void setPadding(Insets padding) {
        this.padding.setValue(padding);
    }

    public double getVerticalPadding() {
        return getPadding().getBottom() + getPadding().getTop();
    }

    public double getHorizontalPadding() {
        return getPadding().getLeft() + getPadding().getRight();
    }
    //endregion
    //endregion

    //region Colors
    private WiresColorPicker wiresColorPicker;

    private Color defaultWireColor = Color.BLACK;
    private Color defaultComparatorColor = Color.BLACK;

    public WiresColorPicker getWiresColorPicker() {
        return wiresColorPicker;
    }

    public void setWiresColorPicker(WiresColorPicker wiresColorPicker) {
        this.wiresColorPicker = wiresColorPicker;
    }

    public Color getDefaultWireColor() {
        return defaultWireColor;
    }

    public void setDefaultWireColor(Color defaultWireColor) {
        this.defaultWireColor = defaultWireColor;
    }

    public Color getDefaultComparatorColor() {
        return defaultComparatorColor;
    }

    public void setDefaultComparatorColor(Color defaultComparatorColor) {
        this.defaultComparatorColor = defaultComparatorColor;
    }
    //endregion

    //region Show Values
    private BooleanProperty showValues = new SimpleBooleanProperty();

    @Override
    public boolean getShowValues() {
        return showValues.get();
    }

    @Override
    public BooleanProperty showValuesProperty() {
        return showValues;
    }

    @Override
    public void setShowValues(boolean showValues) {
        this.showValues.set(showValues);
    }
    //endregion

    //region UI
    private ObjectProperty<NetworkUI> networkUI = new SimpleObjectProperty<>();

    @Override
    public NetworkUI getNetworkUI() {
        return networkUI.get();
    }

    @Override
    public ObjectProperty<NetworkUI> networkUIProperty() {
        return networkUI;
    }

    public void setNetworkUI(NetworkUI networkUI) {
        this.networkUI.set(networkUI);
    }
    //endregion

    @Override
    public void drawNetwork(Network network, ComparatorDepths depths) {
        drawWires(network);
        drawComparators(network, depths);
    }

    @Override
    public void drawComputation(Network network, ComparatorDepths depths, List<? extends Comparable> input) {
        clear();
        drawNetwork(network, depths);

        int size = network.getSize();
        int depthsCount = depths.getCount();
        var colors = getWiresColorPicker().getColors(size);

        var output = new ArrayList<>(input);
        var swaps = new ArrayList<Swap>();
        network.sort(output, swaps);
        var trails = WireTrailsFactory.makeListFromSwaps(size, depths, swaps);

        for (int wire = 0; wire < size; wire++) {
            drawTrailSegment(size, depthsCount, wire, -1, 0, colors.get(wire));
        }

        for (int depth = 0; depth < depthsCount; depth++) {
            drawTrailsForDepth(trails, colors, size, depthsCount, depth);
        }

        if (getShowValues()) {
            drawValues(network, depths, input, trails);
        }
    }

    public void drawTrailsForDepth(List<WireTrail> wireTrails, List<Color> colors, int networkSize, int networkDepth, int depth) {
        for (int wire = 0; wire < networkSize; wire++) {
            int origin = wireTrails.get(wire).getOrigin(depth);
            var color = colors.get(origin);

            drawTrailSegment(networkSize, networkDepth, wire, depth, depth + 1, color);

            var previous = wireTrails.get(wire).getPrevious(depth);
            if (previous == wire) {
                drawComparatorPass(networkSize, networkDepth, wire, depth, color);
            } else {
                drawComparatorSwap(networkSize, networkDepth, previous, wire, depth, color);
            }
        }
    }

    protected abstract void drawValues(Network network, ComparatorDepths depths, List<?> input, List<WireTrail> wireTrails);
}
