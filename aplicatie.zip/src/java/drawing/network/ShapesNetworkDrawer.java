package drawing.network;

import drawing.colors.WiresColorPicker;
import drawing.ui.builders.ShapesNetworkUIBuilder;
import drawing.ui.builders.ShapesNetworkUIBuilderImpl;
import drawing.ui.network.ShapesNetworkUI;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.*;
import sorting_networks.Comparator;
import sorting_networks.depth.ComparatorDepths;
import sorting_networks.network.Network;
import sorting_networks.trail.WireTrail;
import sorting_networks.trail.WireTrailSegment;

import java.util.List;

public class ShapesNetworkDrawer extends AbstractNetworkDrawer {
    private Pane networkLayer;
    private Pane computationLayer;

    public ShapesNetworkDrawer(WiresColorPicker wiresColorPicker, Pane networkLayer, Pane computationLayer) {
        super(wiresColorPicker);
        this.networkLayer = networkLayer;
        this.computationLayer = computationLayer;

        setUiBuilder(new ShapesNetworkUIBuilderImpl());
        setNetworkUI(new ShapesNetworkUI(networkLayer));
    }

    //region UI
    private ShapesNetworkUIBuilder uiBuilder;

    public ShapesNetworkUIBuilder getUiBuilder() {
        return uiBuilder;
    }

    public void setUiBuilder(ShapesNetworkUIBuilder uiBuilder) {
        this.uiBuilder = uiBuilder;
    }
    //endregion

    @Override
    public void clear() {
        networkLayer.getChildren().clear();
        computationLayer.getChildren().clear();
    }

    @Override
    public void drawComparators(Network network, ComparatorDepths depths) {
        int size = network.getSize();
        int depthsCount = depths.getCount();

        for (var comparator : network) {
            drawComparator(size, depthsCount, comparator, depths.get(comparator));
        }
    }

    @Override
    public void drawWires(Network network) {
        int size = network.getSize();

        for (int wire = 0; wire < size; wire++) {
            drawWire(size, wire);
        }
    }

    @Override
    public void drawTrailSegment(int networkSize, int networkDepth, int wire, int fromDepth, int toDepth, Paint paint) {
        double radius = getComparatorRadius();

        var leftRadius = fromDepth >= 0 ? radius : 0;
        var rightRadius = toDepth < networkDepth ? radius : 0;

        double x1 = Math.max(getComparatorX(networkDepth, fromDepth) + leftRadius, getPadding().getLeft());
        double x2 = Math.min(getComparatorX(networkDepth, toDepth) - rightRadius, getWidth() + getPadding().getLeft());
        double y = getWireY(networkSize, wire);

        var shape = new Line(x1, y, x2, y);
        shape.setStrokeWidth(getTrailWidth());
        shape.setStroke(paint);
        computationLayer.getChildren().add(shape);
    }

    @Override
    public void drawComparatorPass(int networkSize, int networkDepth, int wire, int depth, Paint paint) {
        double radius = getComparatorRadius();

        double x1 = Math.max(getComparatorX(networkDepth, depth) + radius, getPadding().getLeft());
        double x2 = Math.min(getComparatorX(networkDepth, depth) - radius, getWidth() + getPadding().getLeft());
        double y = getWireY(networkSize, wire);

        var shape = new Line(x1, y, x2, y);
        shape.setStrokeWidth(getTrailWidth());
        shape.setStroke(paint);
        computationLayer.getChildren().add(shape);
    }

    @Override
    public void drawComparatorSwap(int networkSize, int networkDepth, int fromWire, int toWire, int depth, Paint paint) {
        double x1 = getComparatorX(networkDepth, depth) - getComparatorRadius();
        double x2 = getComparatorX(networkDepth, depth) + getComparatorRadius();
        double y1 = getWireY(networkSize, fromWire);
        double y2 = getWireY(networkSize, toWire);

        var shape = new Line(x1, y1, x2, y2);
        shape.setStroke(paint);
        shape.setStrokeWidth(getTrailWidth());

        computationLayer.getChildren().add(shape);
    }

    @Override
    public double getHeight() {
        return networkLayer.getHeight() - getVerticalPadding();
    }

    @Override
    public double getWidth() {
        return networkLayer.getWidth() - getHorizontalPadding();
    }

    private double getWireY(int networkSize, int index) {
        return getPadding().getTop() + (index + 0.5) * getWireContainerWidth(networkSize);
    }

    private double getComparatorX(int networkDepth, int depth) {
        return getPadding().getLeft() + (depth + 1) * getComparatorContainerWidth(networkDepth);
    }

    private void drawWire(int networkSize, int wire) {
        var shape = new Rectangle();

        shape.setWidth(getWidth());
        shape.setHeight(getWireWidth());

        shape.setX(getPadding().getLeft());
        shape.setY(getWireY(networkSize, wire));

        shape.setFill(getDefaultComparatorColor());

        networkLayer.getChildren().add(shape);

        var wireUI = uiBuilder.makeWire(wire, shape);
        getNetworkUI().getWires().add(wireUI);
    }

    private void drawComparator(int networkSize, int networkDepth, Comparator comparator, int depth) {
        int fromWire = comparator.getX();
        int toWire = comparator.getY();

        var anchor1 = drawComparatorCircle(networkSize, networkDepth, fromWire, depth);
        var anchor2 = drawComparatorCircle(networkSize, networkDepth, toWire, depth);
        var connector = drawComparatorLine(networkSize, networkDepth, fromWire, toWire, depth);

        var comparatorUI = uiBuilder.makeComparator(comparator, connector, anchor1, anchor2);
        getNetworkUI().getComparators().add(comparatorUI);
    }

    private Shape drawComparatorCircle(int networkSize, int networkDepth, int wire, int depth) {
        var shape = new Circle();

        shape.setLayoutX(getComparatorX(networkDepth, depth) + 1);
        shape.setLayoutY(getWireY(networkSize, wire));
        shape.setRadius(getComparatorRadius());
        shape.setFill(getDefaultComparatorColor());

        networkLayer.getChildren().add(shape);

        return shape;
    }

    private Shape drawComparatorLine(int networkSize, int networkDepth, int fromWire, int toWire, int depth) {
        var shape = new Rectangle();

        shape.setWidth(getWireWidth());
        shape.setHeight(getWireY(networkSize, toWire) - getWireY(networkSize, fromWire));

        shape.setX(getComparatorX(networkDepth, depth));
        shape.setY(getWireY(networkSize, fromWire));

        shape.setFill(getDefaultComparatorColor());

        networkLayer.getChildren().add(shape);

        return shape;
    }

    @Override
    protected void drawValues(Network network, ComparatorDepths depths, List<?> input, List<WireTrail> wireTrails) {
        int networkSize = network.getSize();
        int networkDepth = depths.getCount();

        var colors = getWiresColorPicker().getColors(networkSize);

        for (int wire = 0; wire < networkSize; wire++) {
            var segments = wireTrails.get(wire).getSegments().iterator();
            WireTrailSegment previousSegment = null;

            while(true) {
                var segment = segments.hasNext() ? segments.next() : null;

                var origin = (previousSegment != null) ? previousSegment.getOrigin() : wire;
                int startDepth = (previousSegment != null) ? previousSegment.getDepth() : -1;
                var endDepth = (segment != null) ? segment.getDepth() : networkDepth;

                var value = input.get(origin).toString();
                var color = colors.get(origin);

                drawValue(networkSize, networkDepth, wire, startDepth, endDepth, value, color);

                previousSegment = segment;
                if (segment == null) break;
            };
        }
    }

    private void drawValue(int networkSize, int networkDepth, int wire, int startDepth, int endDepth, String value, Color color) {
        var offset = getComparatorX(networkDepth, startDepth);
        var half = (getComparatorX(networkDepth, endDepth) - getComparatorX(networkDepth, startDepth)) / 2.0;
        var x = offset + half - 5;
        var y = getWireY(networkSize, wire) - 32;

       var colorString = String.format("rgb(%f%%, %f%%, %f%%)", color.getRed() * 100, color.getGreen() * 100, color.getBlue() * 100);

        var shape = new Label(value);
        shape.setLayoutX(x);
        shape.setLayoutY(y);
        shape.setStyle("-fx-effect: dropshadow(gaussian, black, 3, 0.5, 0, 0); -fx-font-size: 2em; -fx-padding: 2px; -fx-text-fill: " + colorString);

        computationLayer.getChildren().add(shape);
    }
}
