package controllers.computation.output;

import javafx.collections.ListChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ImplComputationOutputController extends AbstractComputationOutputController implements Initializable {
    @FXML
    private GridPane grid;

    private List<TextField> fields = new ArrayList<>();

    private ListChangeListener<Double> listChangeListener = change -> syncFields();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        computationStateProperty().addListener((o, oldV, newV) -> {
            if (oldV != null) {
                oldV.outputProperty().removeListener(listChangeListener);
            }
            if (newV != null) {
                newV.outputProperty().addListener(listChangeListener);
            }
        });
    }

    @Override
    public void createFields() {
        var output = getComputationState().getOutput();
        var size = output.size();

        deleteFields();
        drawFields(size);

        for (int i = 0; i < size; i++) {
            fields.get(i).setText(output.get(i).toString());
        }
    }

    @Override
    public void deleteFields() {
        if (fields != null) {
            fields.clear();
            grid.getChildren().clear();
            grid.getRowConstraints().clear();
        }
    }

    private void drawFields(int size) {
        for (int i = 0; i < size; i++) {
            RowConstraints row = new RowConstraints();
            row.setVgrow(Priority.ALWAYS);
            grid.getRowConstraints().add(row);

            TextField field = new TextField();
            field.setDisable(true);
            field.getStyleClass().add("output-field");
            grid.getChildren().add(field);
            GridPane.setConstraints(field, 0, i);

            fields.add(field);
        }
    }

    private void syncFields() {
        var output = getComputationState().getOutput();
        if (output != null) {
            createFields();
        }
    }
}
