package controllers.computation.output;

import javafx.beans.property.*;
import sorting_networks.state.ComputationState;
import sorting_networks.state.NetworkState;

public abstract class AbstractComputationOutputController implements ComputationOutputController {
    //region Network State
    private Property<NetworkState> networkState = new SimpleObjectProperty<>();

    @Override
    public NetworkState getNetworkState() {
        return networkState.getValue();
    }

    @Override
    public Property<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.setValue(networkState);
    }
    //endregion

    //region Computation State
    private ObjectProperty<ComputationState> computationState = new SimpleObjectProperty<>();

    @Override
    public ComputationState getComputationState() {
        return computationState.get();
    }

    @Override
    public ObjectProperty<ComputationState> computationStateProperty() {
        return computationState;
    }

    @Override
    public void setComputationState(ComputationState computationState) {
        this.computationState.set(computationState);
    }
    //endregion
}
