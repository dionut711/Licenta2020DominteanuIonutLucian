package controllers.computation.generator;

import javafx.beans.property.ObjectProperty;
import sorting_networks.state.ComputationState;

public interface InputGeneratorController {
    //region ComputationState
    ComputationState getComputationState();

    ObjectProperty<ComputationState> computationStateProperty();

    void setComputationState(ComputationState computationState);
    //endregion

    void clearInput();

    void randomInput();

    void ascendingInput();

    void descendingInput();
}
