package controllers.computation.generator;

import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ImplInputGeneratorController extends AbstractInputGeneratorController {
    private ListChangeListener<Number> inputChangeListener = (change) -> onInputChange();

    //region Nodes
    @FXML
    private Button clearInputButton;

    @FXML
    private Button randomInputButton;

    @FXML
    private Button ascendingInputButton;

    @FXML
    private Button descendingInputButton;
    //endregion

    public ImplInputGeneratorController() {
        computationStateProperty().addListener((o, oldState, newState) -> {
            if (oldState != null) {
                oldState.inputProperty().removeListener(inputChangeListener);
            }
            if (newState != null) {
                newState.inputProperty().addListener(inputChangeListener);
            }
        });
    }

    private void onInputChange() {
        var input = getComputationState().getInput();
        boolean disable = input == null;

        clearInputButton.setDisable(disable);
        randomInputButton.setDisable(disable);
        ascendingInputButton.setDisable(disable);
        descendingInputButton.setDisable(disable);
    }

    //region Actions
    @FXML
    private void onClearInputButton(ActionEvent event) {
        clearInput();
    }

    @FXML
    private void onRandomInputButton(ActionEvent event) {
        randomInput();
    }

    @FXML
    private void onAscendingInputButton(ActionEvent event) {
        ascendingInput();
    }

    @FXML
    private void onDescendingInputButton(ActionEvent event) {
        descendingInput();
    }
    //endregion

    @Override
    public void clearInput() {
        var input = getComputationState().getInput();
        var size = input.size();

        for (int i = 0; i < size; i++) {
            input.set(i, null);
        }
    }

    @Override
    public void randomInput() {
        var input = getComputationState().getInput();
        var size = input.size();

        List<Double> list = new ArrayList<>();
        for (double i = 0; i < size; i++) {
            list.add(i);
        }
        Collections.shuffle(list);

        input.setAll(list);
    }

    @Override
    public void ascendingInput() {
        var input = getComputationState().getInput();
        var size = input.size();

        List<Double> list = new ArrayList<>();
        for (double i = 0; i < size; i++) {
            list.add(i);
        }

        input.setAll(list);
    }

    @Override
    public void descendingInput() {
        var input = getComputationState().getInput();
        var size = input.size();

        List<Double> list = new ArrayList<>();
        for (double i = size - 1; i >= 0; i--) {
            list.add(i);
        }

        input.setAll(list);
    }
}
