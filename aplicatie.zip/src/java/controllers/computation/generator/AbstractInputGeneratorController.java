package controllers.computation.generator;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import sorting_networks.state.ComputationState;

public abstract class AbstractInputGeneratorController implements InputGeneratorController {
    //region Computation State
    private ObjectProperty<ComputationState> computationState = new SimpleObjectProperty<>();

    @Override
    public ComputationState getComputationState() {
        return computationState.get();
    }

    @Override
    public ObjectProperty<ComputationState> computationStateProperty() {
        return computationState;
    }

    @Override
    public void setComputationState(ComputationState computationState) {
        this.computationState.set(computationState);
    }
    //endregion
}
