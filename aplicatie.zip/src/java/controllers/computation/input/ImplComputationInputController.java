package controllers.computation.input;

import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;

import java.net.URL;
import java.util.*;

public class ImplComputationInputController extends AbstractComputationInputController implements Initializable {
    @FXML
    private GridPane grid;

    private List<TextField> fields = new ArrayList<>();

    private ListChangeListener<Double> listChangeListener = change -> syncFields();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        computationStateProperty().addListener((o, oldV, newV) -> {
            if (oldV != null) {
                oldV.inputProperty().removeListener(listChangeListener);
            }
            if (newV != null) {
                newV.inputProperty().addListener(listChangeListener);
            }
        });
    }

    @Override
    public void syncFields() {
        var input = getComputationState().getInput();

        if (input != null) {
            if (fields == null || input.size() != fields.size()) {
                createFields();
            }
            for (int i = 0; i < getComputationState().getInput().size(); i++) {
                var field = fields.get(i);
                var value = input.get(i);

                if (value != null) {
                    field.setText(value.toString());
                }
            }
        }
    }

    @Override
    public void createFields() {
        var size = getNetworkState().getNetwork().getSize();
        var input = getComputationState().getInput();

        deleteFields();
        drawFields(size);

        for (int i = 0; i < size; i++) {
            var field = fields.get(i);
            var value = input.get(i);

            if (value != null) {
                field.setText(value.toString());
            }
            field.textProperty().addListener(this::onFieldTextChange);
        }
    }

    @Override
    public void deleteFields() {
        if (fields != null) {
            for (var field : fields) {
                field.textProperty().removeListener(this::onFieldTextChange);
            }

            fields.clear();
            grid.getChildren().clear();
            grid.getRowConstraints().clear();
        }
    }

    private void drawFields(int size) {
        for (int i = 0; i < size; i++) {
            RowConstraints row = new RowConstraints();
            row.setVgrow(Priority.ALWAYS);
            grid.getRowConstraints().add(row);

            TextField field = new TextField("0");
            grid.getChildren().add(field);
            GridPane.setConstraints(field, 0, i);

            fields.add(field);
        }
    }

    private <T extends String> void onFieldTextChange(ObservableValue<T> obs, String oldValue, String newValue) {
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).textProperty() == obs) {
                Double value = null;
                try {
                    value = Double.parseDouble(newValue);
                } catch (NumberFormatException ignore) {

                } finally {
                    if (!Objects.equals(value, getComputationState().getInput().get(i))) {
                        getComputationState().getInput().set(i, value);
                    }
                }
            }
        }
    }
}
