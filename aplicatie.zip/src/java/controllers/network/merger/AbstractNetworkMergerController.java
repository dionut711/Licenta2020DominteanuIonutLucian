package controllers.network.merger;

import javafx.beans.property.*;
import sorting_networks.state.NetworkState;

public abstract class AbstractNetworkMergerController implements NetworkMergerController {
    //region Network State
    private ObjectProperty<NetworkState> networkState = new SimpleObjectProperty<>();

    @Override
    public NetworkState getNetworkState() {
        return networkState.getValue();
    }

    @Override
    public Property<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.setValue(networkState);
    }
    //endregion

    //region Size
    private IntegerProperty size = new SimpleIntegerProperty();

    @Override
    public int getSize() {
        return size.get();
    }

    @Override
    public IntegerProperty sizeProperty() {
        return size;
    }

    @Override
    public void setSize(int size) {
        this.size.set(size);
    }
    //endregion

    //region M
    private IntegerProperty m = new SimpleIntegerProperty();

    @Override
    public int getM() {
        return m.get();
    }

    @Override
    public IntegerProperty mProperty() {
        return m;
    }

    @Override
    public void setM(int m) {
        this.m.set(m);
    }
    //endregion

    //region N
    private IntegerProperty n = new SimpleIntegerProperty();

    @Override
    public int getN() {
        return n.get();
    }

    @Override
    public IntegerProperty nProperty() {
        return n;
    }

    @Override
    public void setN(int n) {
        this.n.set(n);
    }
    //endregion
}
