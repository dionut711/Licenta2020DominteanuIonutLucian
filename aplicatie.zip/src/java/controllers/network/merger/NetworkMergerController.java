package controllers.network.merger;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.Property;
import sorting_networks.state.NetworkState;

public interface NetworkMergerController {
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    //region Size
    int getSize();

    IntegerProperty sizeProperty();

    void setSize(int size);
    //endregion

    //region M
    int getM();

    IntegerProperty mProperty();

    void setM(int m);
    //endregion

    //region N
    int getN();

    IntegerProperty nProperty();

    void setN(int n);
    //endregion
}
