package controllers.network.merger;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import sorting_networks.factories.MergeNetworkFactory;
import sorting_networks.factories.OddEvenSortFactory;
import sorting_networks.network.Network;

import java.net.URL;
import java.util.ResourceBundle;

public class ImplNetworkMergerController extends AbstractNetworkMergerController implements Initializable {
    //region Nodes
    @FXML
    private Spinner<Integer> mSpinner;

    @FXML
    private Spinner<Integer> nSpinner;

    @FXML
    private Button mergeButton;
    //endregion

    private MergeNetworkFactory factory = new OddEvenSortFactory();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        networkStateProperty().addListener((o, oldState, newState) -> {
            if (oldState != null) {
                oldState.networkProperty().removeListener(this::onNetworkChange);
            }
            if (newState != null) {
                newState.networkProperty().addListener(this::onNetworkChange);
            }
        });

        //region Binding
        mSpinner.valueFactoryProperty().addListener((o, oldV, newV) -> {
            if (oldV != null) {
                oldV.valueProperty().unbindBidirectional(mProperty().asObject());
            }
            if (newV != null) {
                newV.valueProperty().bindBidirectional(mProperty().asObject());
            }
        });

        nSpinner.valueFactoryProperty().addListener((o, oldV, newV) -> {
            if (oldV != null) {
                oldV.valueProperty().unbindBidirectional(nProperty().asObject());
            }
            if (newV != null) {
                newV.valueProperty().bindBidirectional(nProperty().asObject());
            }
        });
        //endregion

        sizeProperty().addListener((o, oldSize, newSize) -> {
            int max = (int) newSize - 1;
            mSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, max));
            nSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, max));
            nSpinner.getValueFactory().setValue(Math.floorDiv((int) newSize, 2));
        });

        //region m + n = size
        mSpinner.valueProperty().addListener((o, oldValue, newValue) -> {
            var size = getSize();
            var n = nSpinner.getValue();
            if (newValue != null && n != null) {
                var newN = size - newValue;
                if (newN != n) {
                    nSpinner.getValueFactory().setValue(newN);
                }
            }
        });

        nSpinner.valueProperty().addListener((o, oldValue, newValue) -> {
            var size = getSize();
            var m = mSpinner.getValue();
            if (newValue != null && m != null) {
                var newM = size - newValue;
                if (newM != m) {
                    mSpinner.getValueFactory().setValue(newM);
                }
            }
        });
        //endregion
    }

    private void onNetworkChange(ObservableValue<? extends Network> o, Network oldNetwork, Network newNetwork) {
        boolean valid = newNetwork != null;

        if (valid) {
            setSize(newNetwork.getSize());
        }

        mSpinner.setDisable(!valid);
        nSpinner.setDisable(!valid);
        mergeButton.setDisable(!valid);
    }

    @FXML
    private void onMergeButton(ActionEvent event) {
        var network = factory.make(getNetworkState().getNetwork(), getM(), getN());
        getNetworkState().setNetwork(network);
    }
}
