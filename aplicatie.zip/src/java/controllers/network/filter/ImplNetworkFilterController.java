package controllers.network.filter;

import generic.PowerOf2SpinnerValueFactory;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import sorting_networks.factories.FilterNetworkFactory;
import sorting_networks.factories.GreenFilterFactory;
import sorting_networks.network.Network;

import java.net.URL;
import java.util.ResourceBundle;

public class ImplNetworkFilterController extends AbstractNetworkFilterController implements Initializable {
    @FXML
    private Spinner<Integer> sizeSpinner;

    @FXML
    private Button generateButton;

    @FXML
    private Button appendButton;

    private FilterNetworkFactory factory = new GreenFilterFactory();

    private ChangeListener<Network> changeListener = (o, oldNetwork, newNetwork) -> {
        if (newNetwork != null) {
            var sqrt = Math.sqrt(newNetwork.getSize());
            var disable = sqrt - Math.floor(sqrt) != 0;
            appendButton.setDisable(disable);
        } else {
            appendButton.setDisable(true);
        }
    };

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        sizeSpinner.setValueFactory(new PowerOf2SpinnerValueFactory(4, 36, 4));

        networkStateProperty().addListener((o, oldState, newState) -> {
            if (oldState != null) {
                oldState.networkProperty().removeListener(changeListener);
            }
            if (newState != null) {
                newState.networkProperty().addListener(changeListener);
            }
            appendButton.setDisable(newState == null);
            generateButton.setDisable(newState == null);
        });
    }

    private void generate() {
        var network = factory.make(sizeSpinner.getValue());
        getNetworkState().setNetwork(network);
    }

    private void append() {
        var network = getNetworkState().getNetwork();
        factory.append(network);
    }

    @FXML
    private void onGenerateButton(ActionEvent event) {
        generate();
    }

    @FXML
    private void onAppendButton(ActionEvent event) {
        append();
    }
}
