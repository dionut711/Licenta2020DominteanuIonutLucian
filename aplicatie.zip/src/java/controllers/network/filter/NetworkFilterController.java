package controllers.network.filter;

import javafx.beans.property.Property;
import sorting_networks.state.NetworkState;

public interface NetworkFilterController {
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion
}
