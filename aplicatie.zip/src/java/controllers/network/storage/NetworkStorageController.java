package controllers.network.storage;

import javafx.beans.property.Property;
import sorting_networks.state.NetworkState;

public interface NetworkStorageController {
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    void load();

    void save();
}
