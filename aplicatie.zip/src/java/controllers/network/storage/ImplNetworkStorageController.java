package controllers.network.storage;

import converters.NetworkStringConverter;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sorting_networks.network.Network;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URL;
import java.util.ResourceBundle;

public class ImplNetworkStorageController extends AbstractNetworkStorageController implements Initializable {
    //region Nodes
    @FXML
    private Pane root;

    @FXML
    private Button saveButton;

    @FXML
    private Button loadButton;
    //endregion

    private NetworkStringConverter converter = new NetworkStringConverter();

    private ChangeListener<Network> changeListener = (o, oldNetwork, newNetwork) -> onNetworkChange();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        networkStateProperty().addListener((o, oldState, newState) -> {
            if (oldState != null) {
                oldState.networkProperty().addListener(changeListener);
            }
            if (newState != null) {
                newState.networkProperty().addListener(changeListener);
            }
        });
        onNetworkChange();
    }

    private void onNetworkChange() {
        var state = getNetworkState();
        boolean disable = state == null || state.getNetwork() == null;
        saveButton.setDisable(disable);
        loadButton.setDisable(disable);
    }

    //region File
    @Override
    public void load() {
        String content;
        var file = getFile(false);

        try {
            FileReader reader = new FileReader(file);
            BufferedReader buffer = new BufferedReader(reader);

            content = buffer.readLine();

            reader.close();
            buffer.close();
        } catch (Exception e) {
            return;
        }

        var network = converter.fromString(content);

        if (network != null) {
            getNetworkState().setNetwork(network);
        }
    }

    @Override
    public void save() {
        var network = getNetworkState().getNetwork();
        var content = converter.toString(network);

        var file = getFile(true);

        try {
            FileWriter writer = new FileWriter(file);
            writer.write(content);
            writer.close();
        } catch (Exception ignore) {
        }
    }

    private File getFile(boolean save) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text files", "*.txt"));

        var stage = (Stage) root.getScene().getWindow();

        return save
                ? fileChooser.showSaveDialog(stage)
                : fileChooser.showOpenDialog(stage);
    }
    //endregion

    //region Actions
    @FXML
    private void onLoadButton(ActionEvent event) {
        load();
    }

    @FXML
    private void onSaveButton(ActionEvent event) {
        save();
    }
    //endregion
}
