package controllers.network.hierarchy;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import sorting_networks.state.NetworkState;

public abstract class AbstractNetworkHierarchyController implements NetworkHierarchyController {
    //region Network State
    private ObjectProperty<NetworkState> networkState = new SimpleObjectProperty<>();

    @Override
    public NetworkState getNetworkState() {
        return networkState.getValue();
    }

    @Override
    public Property<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.setValue(networkState);
    }
    //endregion
}
