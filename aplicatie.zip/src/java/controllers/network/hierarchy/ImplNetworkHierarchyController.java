package controllers.network.hierarchy;

import controllers.comparator.ComparatorController;
import generic.CollapseablePane;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import models.ComparatorTreeNode;
import sorting_networks.Comparator;
import sorting_networks.depth.ComparatorDepths;
import sorting_networks.network.Network;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ImplNetworkHierarchyController extends AbstractNetworkHierarchyController implements Initializable {
    //region Nodes
    @FXML
    public TreeView<ComparatorTreeNode> treeView;

    @FXML
    public Pane contentPane;

    @FXML
    public Button collapseButton;

    @FXML
    public Button extendButton;

    //region Comparator Controls
    @FXML
    private Button createButton;

    @FXML
    private Button editButton;

    @FXML
    private Button deleteButton;

    @FXML
    private Button moveUpButton;

    @FXML
    private Button moveDownButton;
    //endregion
    //endregion

    //region Actions
    @FXML
    private void onCreateButton(ActionEvent event) {
        createComparator();
    }

    @FXML
    private void onEditButton(ActionEvent event) {
        editComparator();
    }

    @FXML
    private void onDeleteButton(ActionEvent event) {
        deleteSelection();
    }

    @FXML
    private void onMoveUpButton(ActionEvent event) {
        moveUpComparator();
    }

    @FXML
    private void onMoveDownButton(ActionEvent event) {
        moveDownComparator();
    }

    @FXML
    private void onClearButton(ActionEvent event) { clearNetwork(); }
    //endregion

    private ChangeListener<ComparatorDepths> depthsChangeListener = (o, oldDepths, newDepths) -> createTree();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        networkStateProperty().addListener((o, oldState, newState) -> {
            if (oldState != null) {
                oldState.depthsProperty().removeListener(depthsChangeListener);
            }
            if (newState != null) {
                newState.depthsProperty().addListener(depthsChangeListener);
            }
        });

        setButtonsDisable();

        var collapsiblePane = new CollapseablePane(contentPane, collapseButton, extendButton);
        collapsiblePane.setContentVisibility(false);
    }

    private void setButtonsDisable() {
        createButton.setDisable(false);
        deleteButton.setDisable(true);
        moveUpButton.setDisable(true);
        moveDownButton.setDisable(true);

        treeView.getSelectionModel().selectedItemProperty().addListener((o, oldV, newV) -> {
            if (newV != null) {
                if (newV.getValue().isComparator()) {
                    var comparator = newV.getValue().getComparator();
                    var comparators = getNetworkState().getNetwork().getComparators();
                    var index = comparators.indexOf(comparator);

                    editButton.setDisable(false);
                    deleteButton.setDisable(false);
                    moveUpButton.setDisable(index - 1 < 0);
                    moveDownButton.setDisable(index + 1 >= comparators.size());
                } else if (newV.getValue().isDepth()) {
                    editButton.setDisable(true);
                    deleteButton.setDisable(false);
                    moveUpButton.setDisable(true);
                    moveDownButton.setDisable(true);
                }
            } else {
                editButton.setDisable(true);
                deleteButton.setDisable(true);
                moveUpButton.setDisable(true);
                moveDownButton.setDisable(true);
            }
        });
    }

    private ComparatorController openComparatorEditor() {
        try {
            var resource = getClass().getClassLoader().getResource("fxml/comparator/ComparatorEditor.fxml");
            var loader = new FXMLLoader(resource);
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            return loader.getController();
        } catch (IOException ignore) {
            return null;
        }
    }

    //region Selection Methods
    @Override
    public void createComparator() {
        var network = getNetworkState().getNetwork();
        var comparators = network.getComparators();

        var controller = openComparatorEditor();
        if (controller != null) {
            controller.init(network.getSize(), new Comparator(0, 1), response -> {
                comparators.add(response);
                treeView.getSelectionModel().selectLast();
                return null;
            });
        }
    }

    @Override
    public void editComparator() {
        var selected = treeView.getSelectionModel().getSelectedItem().getValue();
        if (selected.isComparator()) {
            var network = getNetworkState().getNetwork();
            var comparators = network.getComparators();
            var comparator = selected.getComparator();
            var index = indexOfComparator(network, comparator);

            var controller = openComparatorEditor();
            if (controller != null) {
                controller.init(network.getSize(), comparator, response -> {
                    comparators.set(index, response);
                    return null;
                });
            }
        }
    }

    @Override
    public void deleteSelection() {
        var network = getNetworkState().getNetwork();
        var depths = getNetworkState().getDepths();
        var treeItem = treeView.getSelectionModel().getSelectedItem();

        if (treeItem != null) {
            var model = treeItem.getValue();
            if (model.isComparator()) {
                var comparator = model.getComparator();
                var index = indexOfComparator(network, comparator);
                network.getComparators().remove(index);
            } else if (model.isDepth()) {
                var depth = model.getDepth();
                var comparators = depths.getComparatorsFor(depth);
                network.getComparators().removeAll(comparators);
            }
        }
    }

    @Override
    public void moveUpComparator() {
        var network = getNetworkState().getNetwork();
        var comparators = network.getComparators();
        var treeItem = treeView.getSelectionModel().getSelectedItem();

        if (treeItem != null) {
            var model = treeItem.getValue();
            if (model.isComparator()) {
                var comparator = model.getComparator();
                int index = indexOfComparator(network, comparator);

                if (index - 1 >= 0) {
                    var neighbour = comparators.get(index - 1);

                    comparators.set(index - 1, comparator);
                    comparators.set(index, neighbour);

                    select(comparator);
                }
            }
        }
    }

    @Override
    public void moveDownComparator() {
        var network = getNetworkState().getNetwork();
        var comparators = network.getComparators();
        var treeItem = treeView.getSelectionModel().getSelectedItem();

        if (treeItem != null) {
            var model = treeItem.getValue();
            if (model.isComparator()) {
                var comparator = model.getComparator();
                int index = indexOfComparator(network, comparator);

                if (index + 1 < comparators.size()) {
                    var neighbour = comparators.get(index + 1);

                    comparators.set(index + 1, comparator);
                    comparators.set(index, neighbour);

                    select(comparator);
                }
            }
        }
    }

    @Override
    public void clearNetwork() {
        getNetworkState().getNetwork().getComparators().clear();
    }

    @Override
    public void select(Comparator comparator) {
        var item = getTreeItem(comparator);
        if (item != null) {
            treeView.getSelectionModel().select(item);
        }
    }
    //endregion

    @Override
    public void createTree() {
        var network = getNetworkState().getNetwork();
        var depths = getNetworkState().getDepths();
        var root = new TreeItem<ComparatorTreeNode>();

        for (int depth = 0; depth < depths.getCount(); depth++) {
            var content = new ComparatorTreeNode(depth);
            var item = new TreeItem<>(content);
            item.setExpanded(true);
            root.getChildren().add(item);
        }

        for (var comparator : network) {
            var depth = depths.get(comparator);
            var content = new ComparatorTreeNode(comparator);
            var item = new TreeItem<>(content);
            root.getChildren().get(depth).getChildren().add(item);
        }

        treeView.setRoot(root);
    }

    private TreeItem<ComparatorTreeNode> getTreeItem(Comparator comparator) {
        var depth = getNetworkState().getDepths().get(comparator);
        var items = treeView.getRoot().getChildren().get(depth).getChildren();
        for (var item : items) {
            if (item.getValue().getComparator() == comparator) {
                return item;
            }
        }
        return null;
    }

    private int indexOfComparator(Network network, Comparator comparator) {
        var comparators = network.getComparators();
        var size = comparators.size();

        for (int i = 0; i < size; i++) {
            if (comparators.get(i) == comparator) {
                return i;
            }
        }
        return -1;
    }
}
