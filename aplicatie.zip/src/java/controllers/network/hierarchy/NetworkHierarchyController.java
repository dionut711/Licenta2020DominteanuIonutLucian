package controllers.network.hierarchy;

import javafx.beans.property.Property;
import sorting_networks.Comparator;
import sorting_networks.state.NetworkState;

public interface NetworkHierarchyController {
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    void createTree();

    void createComparator();

    void editComparator();

    void deleteSelection();

    void moveUpComparator();

    void moveDownComparator();

    void clearNetwork();

    void select(Comparator comparator);
}
