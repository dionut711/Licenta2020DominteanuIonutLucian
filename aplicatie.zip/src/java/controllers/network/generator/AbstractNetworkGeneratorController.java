package controllers.network.generator;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import models.Algorithm;
import sorting_networks.factories.NetworkFactory;
import sorting_networks.state.NetworkState;

import java.util.Map;

public abstract class AbstractNetworkGeneratorController implements NetworkGeneratorController {
    //region State
    //region Network State
    private ObjectProperty<NetworkState> networkState = new SimpleObjectProperty<>();

    @Override
    public NetworkState getNetworkState() {
        return networkState.getValue();
    }

    @Override
    public Property<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.setValue(networkState);
    }
    //endregion

    //region Algorithm
    private ObjectProperty<Algorithm> algorithm = new SimpleObjectProperty<>();

    @Override
    public Algorithm getAlgorithm() {
        return algorithm.get();
    }

    @Override
    public ObjectProperty<Algorithm> algorithmProperty() {
        return algorithm;
    }

    @Override
    public void setAlgorithm(Algorithm algorithm) {
        this.algorithm.set(algorithm);
    }
    //endregion

    //region Size
    private ObjectProperty<Integer> size = new SimpleObjectProperty<>();

    @Override
    public Integer getSize() {
        return size.get();
    }

    @Override
    public ObjectProperty<Integer> sizeProperty() {
        return size;
    }

    @Override
    public void setSize(Integer size) {
        this.size.set(size);
    }
    //endregion
    //endregion

    //region Factories
    private Property<Map<Algorithm, NetworkFactory>> factories = new SimpleObjectProperty<>();

    @Override
    public Map<Algorithm, NetworkFactory> getFactories() {
        return factories.getValue();
    }

    @Override
    public Property<Map<Algorithm, NetworkFactory>> factoriesProperty() {
        return factories;
    }

    @Override
    public void setFactories(Map<Algorithm, NetworkFactory> factories) {
        this.factories.setValue(factories);
    }
    //endregion

    //region Factory
    private Property<NetworkFactory> factory = new SimpleObjectProperty<>();

    @Override
    public NetworkFactory getFactory() {
        return factory.getValue();
    }

    @Override
    public Property<NetworkFactory> factoryProperty() {
        return factory;
    }

    @Override
    public void setFactory(NetworkFactory factory) {
        this.factory.setValue(factory);
    }
    //endregion

    public AbstractNetworkGeneratorController() {
        algorithm.addListener((observableValue, oldValue, newValue) -> {
            var factories = getFactories();
            var algorithm = getAlgorithm();
            if (factories != null && algorithm != null) {
                var factory = factories.get(algorithm);
                setFactory(factory);
            }
        });
    }

    @Override
    public void generateNetwork() {
        getNetworkState().setNetwork(getFactory().make(getSize()));
    }
}
