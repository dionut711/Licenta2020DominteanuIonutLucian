package controllers.network.generator;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import models.Algorithm;
import sorting_networks.factories.NetworkFactory;
import sorting_networks.state.NetworkState;

import java.util.Map;

public interface NetworkGeneratorController {
    //region State
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    //region Algorithm
    Algorithm getAlgorithm();

    ObjectProperty<Algorithm> algorithmProperty();

    void setAlgorithm(Algorithm algorithm);
    //endregion

    //region Size
    ObjectProperty<Integer> size = new SimpleObjectProperty<>();

    Integer getSize();

    ObjectProperty<Integer> sizeProperty();

    void setSize(Integer size);
    //endregion
    //endregion

    //region Factories
    Property<Map<Algorithm, NetworkFactory>> factories = new SimpleObjectProperty<>();

    Map<Algorithm, NetworkFactory> getFactories();

    Property<Map<Algorithm, NetworkFactory>> factoriesProperty();

    void setFactories(Map<Algorithm, NetworkFactory> factories);
    //endregion

    //region Factory
    NetworkFactory getFactory();

    Property<NetworkFactory> factoryProperty();

    void setFactory(NetworkFactory factory);
    //endregion

    void generateNetwork();
}
