package controllers.network.generator;

import converters.AlgorithmStringConverter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import models.Algorithm;
import sorting_networks.factories.BubbleSortFactory;
import sorting_networks.factories.InsertionSortFactory;
import sorting_networks.factories.NetworkFactory;
import sorting_networks.factories.OddEvenSortFactory;

import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class ImplNetworkGeneratorController extends AbstractNetworkGeneratorController implements Initializable {
    //region Constants
    private final int STARTING_SIZE = 4;
    private final Algorithm STARTING_ALGORITHM = Algorithm.BUBBLE;

    private final int MIN_SIZE = 2;
    private final int MAX_SIZE = 32;
    //endregion

    //region Nodes
    @FXML
    public Spinner<Integer> sizeInput;

    @FXML
    public ComboBox<Algorithm> algorithmComboBox;

    @FXML
    public Button generateButton;
    //endregion

    //region Options
    private Map<Algorithm, NetworkFactory> options = new HashMap<>() {{
        put(Algorithm.BUBBLE, new BubbleSortFactory());
        put(Algorithm.INSERTION, new InsertionSortFactory());
        put(Algorithm.ODD_EVEN_MERGE, new OddEvenSortFactory());
    }};
    //endregion

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setFactories(options);

        sizeInput.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(MIN_SIZE, MAX_SIZE));
        algorithmComboBox.getItems().setAll(Algorithm.BUBBLE, Algorithm.INSERTION, Algorithm.ODD_EVEN_MERGE);
        algorithmComboBox.setConverter(new AlgorithmStringConverter());

        setSize(STARTING_SIZE);
        setAlgorithm(STARTING_ALGORITHM);

        sizeInput.getValueFactory().valueProperty().bindBidirectional(sizeProperty());
        algorithmComboBox.valueProperty().bindBidirectional(algorithmProperty());
    }

    @FXML
    public void onGenerateButton(ActionEvent event) {
        generateNetwork();
    }
}
