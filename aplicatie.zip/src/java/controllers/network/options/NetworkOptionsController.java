package controllers.network.options;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.Property;
import sorting_networks.state.NetworkState;

public interface NetworkOptionsController {
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    //region Parallel
    boolean isParallel();

    BooleanProperty parallelProperty();

    void setParallel(boolean parallel);
    //endregion

    //region Show Values
    boolean getShowValues();

    BooleanProperty showValuesProperty();

    void setShowValues(boolean showValues);
    //endregion
}
