package controllers.network.options;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import sorting_networks.depth.DepthsCalculator;
import sorting_networks.depth.ParallelDepthsCalculator;
import sorting_networks.depth.SerialDepthsCalculator;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class ImplNetworkOptionsController extends AbstractNetworkOptionsController implements Initializable {
    private final boolean STARTING_PARALLEL = false;
    private final boolean STARTING_SHOW_VALUES = false;

    @FXML
    private CheckBox parallelCheckBox;

    @FXML
    private CheckBox showValuesCheckBox;

    private Map<Boolean, DepthsCalculator> calculators = new HashMap<>() {{
        put(true, new ParallelDepthsCalculator());
        put(false, new SerialDepthsCalculator());
    }};

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setParallel(STARTING_PARALLEL);
        setShowValues(STARTING_SHOW_VALUES);

        parallelCheckBox.selectedProperty().bindBidirectional(parallelProperty());
        showValuesCheckBox.selectedProperty().bindBidirectional(showValuesProperty());

        parallelProperty().addListener((observableValue, oldValue, newValue) -> {
            getNetworkState().setDepthsCalculator(calculators.get(newValue));
        });
    }
}
