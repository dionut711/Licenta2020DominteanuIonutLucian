package controllers.network.options;

import javafx.beans.property.*;
import sorting_networks.state.NetworkState;

public abstract class AbstractNetworkOptionsController implements NetworkOptionsController {
    //region Network State
    private ObjectProperty<NetworkState> networkState = new SimpleObjectProperty<>();

    @Override
    public NetworkState getNetworkState() {
        return networkState.getValue();
    }

    @Override
    public Property<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.setValue(networkState);
    }
    //endregion

    //region Parallel
    private BooleanProperty parallel = new SimpleBooleanProperty();

    @Override
    public boolean isParallel() {
        return parallel.get();
    }

    @Override
    public BooleanProperty parallelProperty() {
        return parallel;
    }

    @Override
    public void setParallel(boolean parallel) {
        this.parallel.set(parallel);
    }
    //endregion

    //region Show Values
    private BooleanProperty showValues = new SimpleBooleanProperty();

    @Override
    public boolean getShowValues() {
        return showValues.get();
    }

    @Override
    public BooleanProperty showValuesProperty() {
        return showValues;
    }

    @Override
    public void setShowValues(boolean showValues) {
        this.showValues.set(showValues);
    }
    //endregion
}
