package controllers.network.tester;

import generic.CollapseablePane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import sorting_networks.test.NetworkBinaryTester;
import sorting_networks.test.TestResult;
import sorting_networks.test.TestResultRow;
import sorting_networks.network.Network;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

public class ImplNetworkTesterController extends AbstractNetworkTesterController implements Initializable {
    //region Nodes
    @FXML
    private Pane contentPane;

    @FXML
    private Button collapseButton;

    @FXML
    private Button extendButton;

    @FXML
    private Labeled countField;

    @FXML
    private Labeled sortedField;

    @FXML
    private Labeled failedField;

    @FXML
    private Labeled timeField;

    @FXML
    private TableView<TestResultRow> outputView;
    //endregion

    private NetworkBinaryTester tester = new NetworkBinaryTester();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        var collapsible = new CollapseablePane(contentPane, collapseButton, extendButton);
        collapsible.setContentVisibility(false);
    }

    @FXML
    private void onRunButton(ActionEvent event) {
        var network = getNetworkState().getNetwork();
        var testResult = tester.test(network);

        int count = testResult.count();
        int correct = testResult.correct();
        long time = testResult.getTime();

        outputView.getItems().setAll(testResult.getRows());
        countField.setText(Integer.toString(count));
        sortedField.setText(Integer.toString(correct));
        failedField.setText(Integer.toString(count - correct));
        timeField.setText(time + " ns");
    }
}
