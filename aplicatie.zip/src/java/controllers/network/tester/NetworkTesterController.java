package controllers.network.tester;

import javafx.beans.property.Property;
import sorting_networks.test.TestResult;
import sorting_networks.network.Network;
import sorting_networks.state.NetworkState;

public interface NetworkTesterController {
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion
}
