package controllers;

import controllers.network.filter.NetworkFilterController;
import controllers.network.storage.NetworkStorageController;
import controllers.visual.capture.NetworkCaptureController;
import controllers.visual.drawer.NetworkDrawerController;
import controllers.network.generator.ImplNetworkGeneratorController;
import controllers.computation.generator.InputGeneratorController;
import controllers.network.hierarchy.ImplNetworkHierarchyController;
import controllers.computation.input.ComputationInputController;
import controllers.network.merger.NetworkMergerController;
import controllers.network.options.NetworkOptionsController;
import controllers.computation.output.ComputationOutputController;
import controllers.visual.player.ComputationPlayerController;
import controllers.network.tester.NetworkTesterController;
import controllers.visual.zoom.NetworkZoomController;
import drawing.ui.NetworkComponentType;
import drawing.ui.network.NetworkClickEvent;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;
import javafx.scene.transform.Scale;
import sorting_networks.state.ComputationState;
import sorting_networks.state.NetworkState;
import sorting_networks.depth.SerialDepthsCalculator;
import sorting_networks.state.SimpleComputationState;
import sorting_networks.state.SimpleNetworkState;

import java.net.URL;
import java.util.*;

public class MainController implements Initializable {
    private final int SAMPLE_SIZE = 6;

    //region Network State
    private ObjectProperty<NetworkState> networkState = new SimpleObjectProperty<>();

    public NetworkState getNetworkState() {
        return networkState.getValue();
    }

    public Property<NetworkState> networkStateProperty() {
        return networkState;
    }

    public void setNetworkState(NetworkState networkState) {
        this.networkState.setValue(networkState);
    }
    //endregion

    //region Computation State
    private ObjectProperty<ComputationState> computationState = new SimpleObjectProperty<>();

    public ComputationState getComputationState() {
        return computationState.get();
    }

    public ObjectProperty<ComputationState> computationStateProperty() {
        return computationState;
    }

    public void setComputationState(ComputationState computationState) {
        this.computationState.set(computationState);
    }
    //endregion

    //region Controllers
    @FXML
    private ImplNetworkGeneratorController networkGeneratorController;

    @FXML
    private NetworkDrawerController networkDrawerController;

    @FXML
    private ImplNetworkHierarchyController networkHierarchyController;

    @FXML
    private NetworkOptionsController networkOptionsController;

    @FXML
    private ComputationInputController computationInputController;

    @FXML
    private ComputationOutputController computationOutputController;

    @FXML
    private NetworkTesterController networkTesterController;

    @FXML
    private NetworkMergerController networkMergerController;

    @FXML
    private NetworkZoomController networkZoomController;

    @FXML
    private NetworkStorageController networkStorageController;

    @FXML
    private ComputationPlayerController computationPlayerController;

    @FXML
    private InputGeneratorController inputGeneratorController;

    @FXML
    private NetworkCaptureController networkCaptureController;

    @FXML
    private NetworkFilterController networkFilterController;
    //endregion

    //region Nodes
    @FXML
    private ScrollPane networkScrollContainer;

    @FXML
    private Pane networkScrollContent;

    @FXML
    private Node networkDrawer;
    //endregion

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // States init
        var networkState = new SimpleNetworkState(new SerialDepthsCalculator());
        var computationState = new SimpleComputationState();
        computationState.setNetworkState(networkState);
        setNetworkState(networkState);
        setComputationState(computationState);

        // Network State
        networkHierarchyController.setNetworkState(networkState);
        networkGeneratorController.setNetworkState(networkState);
        networkDrawerController.setNetworkState(networkState);
        networkOptionsController.setNetworkState(networkState);
        computationInputController.setNetworkState(networkState);
        computationOutputController.setNetworkState(networkState);
        networkTesterController.setNetworkState(networkState);
        networkMergerController.setNetworkState(networkState);
        networkStorageController.setNetworkState(networkState);
        computationPlayerController.setNetworkState(networkState);
        networkFilterController.setNetworkState(networkState);

        // Computation State
        networkDrawerController.setComputationState(computationState);
        computationInputController.setComputationState(computationState);
        computationOutputController.setComputationState(computationState);
        inputGeneratorController.setComputationState(computationState);

        // Bind network drawer and computation player
        computationPlayerController.computationPercentageProperty().bindBidirectional(networkDrawerController.computationPercentageProperty());

        // Bind network drawer and network options
        networkDrawerController.getDrawer().showValuesProperty().bindBidirectional(networkOptionsController.showValuesProperty());
        networkOptionsController.showValuesProperty().addListener((o, oldV, newV) -> networkDrawerController.redraw());

        // Capture
        networkCaptureController.setTarget(networkDrawer);

        // Scroll
        networkZoomController.setContainer(networkScrollContainer);
        networkZoomController.setContent(networkScrollContent);

        var networkUIProperty = networkDrawerController.getDrawer().networkUIProperty();
        networkUIProperty.getValue().addClickListener(this::onNetworkUIClick);
        networkUIProperty.addListener((observableValue, oldValue, newValue) -> {
            oldValue.removeClickListener(this::onNetworkUIClick);
            newValue.addClickListener(this::onNetworkUIClick);
        });

        // sample
        networkGeneratorController.setSize(SAMPLE_SIZE);
        networkGeneratorController.generateNetwork();
        inputGeneratorController.randomInput();
    }

    private void onNetworkUIClick(NetworkClickEvent event) {
        if (event.getComponentType() == NetworkComponentType.COMPARATOR_ANCHOR || event.getComponentType() == NetworkComponentType.COMPARATOR_CONNECTOR) {
            var comparator = event.getComparatorEvent().getComparatorUI().getComparator();
            networkHierarchyController.select(comparator);
        }
    }
}
