package controllers.visual.zoom;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Labeled;

import java.net.URL;
import java.util.ResourceBundle;

public class ImplNetworkZoomController extends AbstractNetworkZoomController implements Initializable {
    private final double ZOOM_FACTOR = 0.25;

    @FXML
    private Labeled zoomField;

    @FXML
    private Button zoomOutButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // resize content on zoom change
        percentageProperty().addListener((o, oldZoom, newZoom) -> {
            if (newZoom != null) {
                var zoom = (double) newZoom;

                if (zoom < 1) {
                    setPercentage(1);
                } else if (oldZoom == null || !oldZoom.equals(zoom)){
                    resize(zoom);
                }
            }
        });

        // disable zoom out on 100%
        percentageProperty().addListener((o, oldZoom, newZoom) ->
                zoomOutButton.setDisable(newZoom == null || (double) newZoom == 1));

        // listen to container resize
        containerProperty().addListener((o, oldV, newV) -> {
            if (oldV != null) {
                oldV.widthProperty().removeListener(this::onSizeChange);
                oldV.heightProperty().removeListener(this::onSizeChange);
            }
            if (newV != null) {
                newV.widthProperty().addListener(this::onSizeChange);
                newV.heightProperty().addListener(this::onSizeChange);
            }
        });

        // display current zoom
        zoomField.textProperty().bind(percentageProperty().asString());

        // init
        setPercentage(1.1);
        setPercentage(1);
    }

    private void onSizeChange(ObservableValue<? extends Number> o, Number oldSize, Number newSize) {
        resize(getPercentage());
    }

    private void resize(double zoom) {
        var container  = getContainer();
        var content = getContent();

        if (container != null && content != null) {
            if (zoom == 1) {
                container.setFitToHeight(true);
                container.setFitToWidth(true);
            } else {
                container.setFitToHeight(false);
                container.setFitToWidth(false);
                content.setPrefWidth(container.getWidth() * zoom);
                content.setPrefHeight(container.getHeight() * zoom);
            }
        }
    }

    @FXML
    private void onZoomInButton(ActionEvent event) {
        setPercentage(getPercentage() + ZOOM_FACTOR);
    }

    @FXML
    private void onZoomOutButton(ActionEvent event) {
        setPercentage(getPercentage() - ZOOM_FACTOR);
    }
}
