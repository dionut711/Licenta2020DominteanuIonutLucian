package controllers.visual.zoom;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Region;

public abstract class AbstractNetworkZoomController implements NetworkZoomController {
    //region Container
    private ObjectProperty<ScrollPane> container = new SimpleObjectProperty<>();

    @Override
    public ScrollPane getContainer() {
        return container.get();
    }

    @Override
    public ObjectProperty<ScrollPane> containerProperty() {
        return container;
    }

    @Override
    public void setContainer(ScrollPane container) {
        this.container.set(container);
    }
    //endregion

    //region Content
    private ObjectProperty<Region> content = new SimpleObjectProperty<>();

    @Override
    public Region getContent() {
        return content.get();
    }

    @Override
    public ObjectProperty<Region> contentProperty() {
        return content;
    }

    @Override
    public void setContent(Region content) {
        this.content.set(content);
    }
    //endregion

    //region Percentage
    private DoubleProperty percentage = new SimpleDoubleProperty();

    @Override
    public double getPercentage() {
        return percentage.get();
    }

    @Override
    public DoubleProperty percentageProperty() {
        return percentage;
    }

    @Override
    public void setPercentage(double percentage) {
        this.percentage.set(percentage);
    }
    //endregion
}
