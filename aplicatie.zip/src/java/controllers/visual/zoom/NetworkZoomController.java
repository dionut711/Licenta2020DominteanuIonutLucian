package controllers.visual.zoom;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Region;

public interface NetworkZoomController {
    //region Container
    ScrollPane getContainer();

    ObjectProperty<ScrollPane> containerProperty();

    void setContainer(ScrollPane container);
    //endregion

    //region Content
    Region getContent();

    ObjectProperty<Region> contentProperty();

    void setContent(Region content);
    //endregion

    //region Percentage
    double getPercentage();

    DoubleProperty percentageProperty();

    void setPercentage(double percentage);
    //endregion
}
