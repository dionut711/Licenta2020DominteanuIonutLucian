package controllers.visual.drawer;

import drawing.network.SortingNetworkDrawer;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import sorting_networks.Swap;
import sorting_networks.depth.ComparatorDepths;
import sorting_networks.state.ComputationState;
import sorting_networks.state.NetworkState;

import java.util.List;

public abstract class AbstractNetworkDrawerController implements NetworkDrawerController {
    private ChangeListener<ComparatorDepths> depthsChangeListener = (o, oldDepths, newDepths) -> redraw();

    public AbstractNetworkDrawerController() {
        networkStateProperty().addListener((oState, oldState, newState) -> {
            if (oldState != null) {
                oldState.depthsProperty().removeListener(depthsChangeListener);
            }
            if (newState != null) {
                newState.depthsProperty().addListener(depthsChangeListener);
            }
        });
        computationStateProperty().addListener(
                (o, oldState, newState) -> newState.swapsProperty().addListener(
                        (o1, oldSwaps, newSwaps) -> redraw()
                )
        );
    }

    @Override
    public void redraw() {
        var network = getNetworkState().getNetwork();
        var depths = getNetworkState().getDepths();
        var swaps = getComputationState().getSwaps();

        drawer.clear();

        if (network != null && depths != null) {
            drawer.drawNetwork(network, depths);
            if (swaps != null && isCompatible(depths, swaps)) {
                var input = getComputationState().getInput();
                drawer.drawComputation(network, depths, input);
            }
        }
    }

    private boolean isCompatible(ComparatorDepths depths, List<Swap> swaps) {
        for (var swap: swaps) {
            try {
                depths.get(swap.getComparator());
            } catch (NullPointerException e) {
                return false;
            }
        }
        return true;
    }

    //region Network Drawer
    private SortingNetworkDrawer drawer;

    @Override
    public SortingNetworkDrawer getDrawer() {
        return drawer;
    }

    @Override
    public void setDrawer(SortingNetworkDrawer drawer) {
        this.drawer = drawer;
    }
    //endregion

    //region Network State
    private Property<NetworkState> networkState = new SimpleObjectProperty<>();

    @Override
    public NetworkState getNetworkState() {
        return networkState.getValue();
    }

    @Override
    public Property<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.setValue(networkState);
    }
    //endregion

    //region Computation State
    private ObjectProperty<ComputationState> computationState = new SimpleObjectProperty<>();

    @Override
    public ComputationState getComputationState() {
        return computationState.get();
    }

    @Override
    public ObjectProperty<ComputationState> computationStateProperty() {
        return computationState;
    }

    @Override
    public void setComputationState(ComputationState computationState) {
        this.computationState.set(computationState);
    }
    //endregion

    //region Computation Percentage
    private DoubleProperty computationPercentage = new SimpleDoubleProperty(1);

    @Override
    public double getComputationPercentage() {
        return computationPercentage.get();
    }

    @Override
    public DoubleProperty computationPercentageProperty() {
        return computationPercentage;
    }

    @Override
    public void setComputationPercentage(double computationPercentage) {
        this.computationPercentage.set(computationPercentage);
    }
    //endregion
}
