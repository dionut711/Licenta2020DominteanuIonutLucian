package controllers.visual.drawer;

import drawing.network.SortingNetworkDrawer;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.Property;
import sorting_networks.state.ComputationState;
import sorting_networks.state.NetworkState;

public interface NetworkDrawerController {
    //region Network State
    NetworkState getNetworkState();

    Property<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    //region Computation State
    ComputationState getComputationState();

    Property<ComputationState> computationStateProperty();

    void setComputationState(ComputationState computationState);
    //endregion

    //region Network Drawer
    SortingNetworkDrawer getDrawer();

    void setDrawer(SortingNetworkDrawer drawer);
    //endregion

    //region Computation Percentage
    double getComputationPercentage();

    DoubleProperty computationPercentageProperty();

    void setComputationPercentage(double percentage);
    //endregion

    void redraw();
}
