package controllers.visual.drawer;

import drawing.colors.RainbowWiresColorPicker;
import drawing.network.ShapesNetworkDrawer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.util.ResourceBundle;

public class ImplNetworkDrawerController extends AbstractNetworkDrawerController implements Initializable {
    @FXML
    private Pane networkLayer;

    @FXML
    private Pane computationLayer;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setDrawer(new ShapesNetworkDrawer(new RainbowWiresColorPicker(), networkLayer, computationLayer));

        getDrawer().setPadding(new Insets(10));

        networkLayer.widthProperty().addListener((observableValue, number, t1) -> redraw());
        networkLayer.heightProperty().addListener((observableValue, number, t1) -> redraw());
        computationLayer.widthProperty().addListener((observableValue, number, t1) -> redrawClip());
        computationLayer.heightProperty().addListener((observableValue, number, t1) -> redrawClip());

        computationPercentageProperty().addListener((obs, oldV, newV) -> redrawClip());
    }

    private void redrawClip() {
        var depths = getNetworkState().getDepths();
        var swaps = getComputationState().getSwaps();

        if (depths != null && swaps != null) {
            var width = computationLayer.getWidth() * getComputationPercentage();
            var height = computationLayer.getHeight();
            var clip = new Rectangle(width, height);
            computationLayer.setClip(clip);
        }
    }
}
