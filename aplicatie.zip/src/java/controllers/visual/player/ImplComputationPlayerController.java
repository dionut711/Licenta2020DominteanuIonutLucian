package controllers.visual.player;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class ImplComputationPlayerController extends AbstractComputationPlayerController implements Initializable {
    final double SPEED_MODIFIER = 0.2;
    final double FRAME_DURATION = 0.01;

    final double MIN_SPEED = 0.4;
    final double MAX_SPEED = 2;

    //region Nodes
    @FXML
    private Slider slider;

    @FXML
    private ProgressBar progress;

    @FXML
    private Button toggleButton;

    @FXML
    private Button skipForwardButton;

    @FXML
    private Button skipBackwardButton;

    @FXML
    private Button prevDepthButton;

    @FXML
    private Button nextDepthButton;

    @FXML
    private Slider speedSlider;
    //endregion

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        progress.progressProperty().bindBidirectional(slider.valueProperty());
        slider.valueProperty().bindBidirectional(computationPercentageProperty());
        slider.setMin(0);
        slider.setMax(1);

        speedSlider.valueProperty().bindBidirectional(animationSpeedProperty());
        speedSlider.setMin(0);
        speedSlider.setMax(1);
        setAnimationSpeed(0.5);

        initPlayAnimation();

        playingProperty().addListener((o, oldV, newV) -> toggleButton.setText(newV ? "⏸" : "▶"));
        computationPercentageProperty().addListener((o, oldV, newV) -> {
            toggleButton.setDisable((double)newV == 1);
            nextDepthButton.setDisable((double)newV == 1);
            prevDepthButton.setDisable((double)newV == 0);
        });

        setComputationPercentage(0);
        setComputationPercentage(1);
    }

    private void initPlayAnimation() {
        var keyFrame = new KeyFrame(Duration.seconds(FRAME_DURATION), event -> {
            var percentage = getComputationPercentage() + getSpeedForFrame();
            if (percentage > 1) {
                percentage = 1;
                setPlaying(false);
            }
            setComputationPercentage(percentage);
        });
        var timeline = getTimeline();
        timeline.stop();
        timeline.getKeyFrames().clear();
        timeline.getKeyFrames().add(keyFrame);
        timeline.setCycleCount(Timeline.INDEFINITE);
    }

    private double getSpeedForFrame() {
        var lerp = MIN_SPEED + (MAX_SPEED - MIN_SPEED) * getAnimationSpeed();
        var frame = FRAME_DURATION * SPEED_MODIFIER;
        return lerp * frame;
    }

    private void goToDepthOffset(int offset) {
        var depths = getNetworkState().getDepths();
        if (depths != null) {
            var percent = getComputationPercentage();
            var count = depths.getCount() + 1;
            double stepSize = 1.0d / count;

            var newStep = (int)Math.floor(percent / stepSize) + offset;
            double newPercent = newStep * stepSize;

            while (newPercent == percent) newPercent += Math.signum(offset); // block fix

            setComputationPercentage(newPercent);
        }
    }

    //region Actions
    @FXML
    private void onToggleButton(ActionEvent event) {
        setPlaying(!isPlaying());
    }

    @FXML
    private void onSkipForwardButton(ActionEvent event) {
        setComputationPercentage(1);
    }

    @FXML
    private void onSkipBackwardButton(ActionEvent event) {
        setComputationPercentage(0);
    }

    @FXML
    private void onNextDepthButton(ActionEvent event) {
        goToDepthOffset(1);
    }

    @FXML
    private void onPrevDepthButton(ActionEvent event) {
        goToDepthOffset(-1);
    }
    //endregion
}
