package controllers.visual.player;

import javafx.animation.Timeline;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import sorting_networks.state.NetworkState;

public interface ComputationPlayerController {
    //region Network State
    NetworkState getNetworkState();

    ObjectProperty<NetworkState> networkStateProperty();

    void setNetworkState(NetworkState networkState);
    //endregion

    //region Computation Percentage
    double getComputationPercentage();

    DoubleProperty computationPercentageProperty();

    void setComputationPercentage(double percentage);
    //endregion

    //region Animation Speed
    double getAnimationSpeed();

    DoubleProperty animationSpeedProperty();

    void setAnimationSpeed(double speed);
    //endregion

    //region Timeline
    Timeline getTimeline();

    ObjectProperty<Timeline> timelineProperty();

    void setTimeline(Timeline timeline);
    //endregion

    //region Playing
    boolean isPlaying();

    BooleanProperty playingProperty();

    void setPlaying(boolean playing);
    //endregion
}
