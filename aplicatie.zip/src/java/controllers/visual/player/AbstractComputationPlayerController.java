package controllers.visual.player;

import javafx.animation.Timeline;
import javafx.beans.property.*;
import sorting_networks.state.NetworkState;

public abstract class AbstractComputationPlayerController implements ComputationPlayerController {
    public AbstractComputationPlayerController() {
        playingProperty().addListener((o, oldV, newV) -> {
            if (newV) {
                getTimeline().play();
            } else {
                getTimeline().stop();
            }
        });
    }

    //region Network State
    ObjectProperty<NetworkState> networkState = new SimpleObjectProperty<>();

    @Override
    public NetworkState getNetworkState() {
        return networkState.get();
    }

    @Override
    public ObjectProperty<NetworkState> networkStateProperty() {
        return networkState;
    }

    @Override
    public void setNetworkState(NetworkState networkState) {
        this.networkState.set(networkState);
    }
    //endregion

    //region Computation Percentage
    private DoubleProperty computationPercentage = new SimpleDoubleProperty(1);

    @Override
    public double getComputationPercentage() {
        return computationPercentage.get();
    }

    @Override
    public DoubleProperty computationPercentageProperty() {
        return computationPercentage;
    }

    @Override
    public void setComputationPercentage(double computationPercentage) {
        this.computationPercentage.set(computationPercentage);
    }
    //endregion

    //region Animation Speed
    private DoubleProperty animationSpeed = new SimpleDoubleProperty(1);

    @Override
    public double getAnimationSpeed() {
        return animationSpeed.get();
    }

    @Override
    public DoubleProperty animationSpeedProperty() {
        return animationSpeed;
    }

    @Override
    public void setAnimationSpeed(double animationSpeed) {
        this.animationSpeed.set(animationSpeed);
    }
    //endregion

    //region Timeline
    private ObjectProperty<Timeline> timeline = new SimpleObjectProperty<>(new Timeline());

    @Override
    public Timeline getTimeline() {
        return timeline.get();
    }

    @Override
    public ObjectProperty<Timeline> timelineProperty() {
        return timeline;
    }

    @Override
    public void setTimeline(Timeline timeline) {
        this.timeline.set(timeline);
    }
    //endregion

    //region Playing
    private BooleanProperty playing = new SimpleBooleanProperty();

    @Override
    public boolean isPlaying() {
        return playing.get();
    }

    @Override
    public BooleanProperty playingProperty() {
        return playing;
    }

    @Override
    public void setPlaying(boolean playing) {
        this.playing.set(playing);
    }
    //endregion
}
