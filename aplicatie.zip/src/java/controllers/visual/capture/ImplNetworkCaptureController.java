package controllers.visual.capture;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class ImplNetworkCaptureController extends AbstractNetworkCaptureController {
    @FXML
    private void onSaveImageButton(ActionEvent event) {
        saveImage();
    }

    @Override
    public Image getImage() {
        var target = getTarget();

        int width = (int) target.getBoundsInLocal().getWidth();
        int height = (int) target.getBoundsInLocal().getHeight();

        var image = new WritableImage(width, height);
        var params = new SnapshotParameters();
        target.snapshot(params, image);

        return image;
    }

    @Override
    public void saveImage() {
        var image = getImage();
        File file = getFile();

        if (file != null) {
            try {
                ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
            } catch (IOException ignore) {
                System.out.println(ignore);
            }
        }
    }

    private File getFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image", "*.png"));

        var stage = (Stage) getTarget().getScene().getWindow();

        return fileChooser.showSaveDialog(stage);
    }
}
