package controllers.visual.capture;

import javafx.scene.Node;

public abstract class AbstractNetworkCaptureController implements NetworkCaptureController {
    private Node target;

    @Override
    public Node getTarget() {
        return target;
    }

    @Override
    public void setTarget(Node target) {
        this.target = target;
    }
}
