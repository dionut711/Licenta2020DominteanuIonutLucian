package controllers.visual.capture;

import javafx.scene.Node;
import javafx.scene.image.Image;

public interface NetworkCaptureController {
    Node getTarget();

    void setTarget(Node target);

    Image getImage();

    void saveImage();
}
