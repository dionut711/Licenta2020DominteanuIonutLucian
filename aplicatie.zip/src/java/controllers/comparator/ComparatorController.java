package controllers.comparator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import sorting_networks.Comparator;

public class ComparatorController {
    //region Nodes
    @FXML
    private Spinner<Integer> spinnerX;

    @FXML
    private Spinner<Integer> spinnerY;

    @FXML
    private Button confirmButton;

    @FXML
    private Button cancelButton;
    //endregion

    private Callback<Comparator, Void> callback;

    public void init(int size, Comparator comparator, Callback<Comparator, Void> callback) {
        this.callback = callback;

        spinnerX.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, size - 1));
        spinnerY.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, size - 1));

        spinnerX.getValueFactory().setValue(comparator.getX());
        spinnerY.getValueFactory().setValue(comparator.getY());

        spinnerX.getValueFactory().valueProperty().addListener((o, oldV, newV) -> {
            confirmButton.setDisable(newV.equals(spinnerY.getValueFactory().getValue()));
        });
        spinnerY.getValueFactory().valueProperty().addListener((o, oldV, newV) -> {
            confirmButton.setDisable(newV.equals(spinnerX.getValueFactory().getValue()));
        });
    }

    @FXML
    private void onConfirmButton(ActionEvent event) {
        int x = Math.min(spinnerX.getValue(), spinnerY.getValue());
        int y = Math.max(spinnerX.getValue(), spinnerY.getValue());
        Comparator comparator = new Comparator(x, y);
        callback.call(comparator);
        ((Stage)(confirmButton.getScene().getWindow())).close();
    }
}
