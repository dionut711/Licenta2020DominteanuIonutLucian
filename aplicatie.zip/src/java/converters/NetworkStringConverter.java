package converters;

import javafx.util.StringConverter;
import sorting_networks.Comparator;
import sorting_networks.network.Network;
import sorting_networks.network.SimpleNetwork;

public class NetworkStringConverter extends StringConverter<Network> {
    @Override
    public String toString(Network network) {
        StringBuilder builder = new StringBuilder();

        builder.append(network.getSize());
        builder.append(";");
        for (var comparator: network.getComparators()) {
            builder.append(String.format(" (%d, %d);", comparator.getX(), comparator.getY()));
        }
        builder.deleteCharAt(builder.length() - 1);

        return builder.toString();
    }

    @Override
    public Network fromString(String s) {
        var items = s.split("; ");

        Network network;

        try {
            int size = Integer.parseInt(items[0]);
            network = new SimpleNetwork(size);
        } catch (Exception e) {
            return null;
        }

        for (int i = 1; i < items.length; i++) {
            var content = items[i]
                    .replace("(", "")
                    .replace(")", "");
            var xy = content.split(", ");

            try {
                int x = Integer.parseInt(xy[0]);
                int y = Integer.parseInt(xy[1]);

                network.getComparators().add(new Comparator(x, y));
            } catch (Exception e) {
                return null;
            }
        }

        return network;
    }
}
