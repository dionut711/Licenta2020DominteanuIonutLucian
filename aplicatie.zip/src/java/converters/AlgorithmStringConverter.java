package converters;

import javafx.util.StringConverter;
import models.Algorithm;

import java.util.HashMap;
import java.util.Map;

public class AlgorithmStringConverter extends StringConverter<Algorithm> {
    Map<Algorithm, String> map = new HashMap<>() {{
        put(Algorithm.BUBBLE, "Bubble");
        put(Algorithm.INSERTION, "Insertion");
        put(Algorithm.ODD_EVEN_MERGE, "Odd-Even Merge");
    }};

    @Override
    public String toString(Algorithm algorithm) {
        return map.get(algorithm);
    }

    @Override
    public Algorithm fromString(String s) {
        for (var entry: map.entrySet())
        {
            if (entry.getValue() == s)
                return entry.getKey();
        }
        return null;
    }
}
