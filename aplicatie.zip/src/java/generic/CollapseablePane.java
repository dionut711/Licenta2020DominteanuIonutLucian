package generic;

import javafx.scene.Node;
import javafx.scene.control.Button;

public class CollapseablePane {
    private Node content;
    private Button collapseButton;
    private Button extendButton;

    public CollapseablePane(Node content, Button collapseButton, Button extendButton) {
        this.content = content;
        this.collapseButton = collapseButton;
        this.extendButton = extendButton;

        content.managedProperty().bind(content.visibleProperty());
        collapseButton.managedProperty().bind(collapseButton.visibleProperty());
        extendButton.managedProperty().bind(extendButton.visibleProperty());

        collapseButton.setOnAction(event -> setContentVisibility(false));
        extendButton.setOnAction(event -> setContentVisibility(true));
    }

    public void setContentVisibility(boolean visibility) {
        content.setVisible(visibility);
        collapseButton.setVisible(visibility);
        extendButton.setVisible(!visibility);
    }
}
