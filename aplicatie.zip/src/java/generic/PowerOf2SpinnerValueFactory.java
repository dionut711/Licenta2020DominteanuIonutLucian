package generic;

import javafx.scene.control.SpinnerValueFactory;

public class PowerOf2SpinnerValueFactory extends SpinnerValueFactory<Integer> {
    private int min;
    private int max;

    public PowerOf2SpinnerValueFactory(int min, int max, int initialValue) {
        this.min = min;
        this.max = max;
        setValue(initialValue);
    }

    @Override
    public void decrement(int i) {
        var x = exponentFloor(getValue()) - i;
        setValue(Math.max((int) Math.pow(2, x), min));
    }

    @Override
    public void increment(int i) {
        var x = exponentFloor(getValue()) + i;
        setValue(Math.min((int) Math.pow(2, x), max));
    }

    private int exponentFloor(int x) {
        int n = 1;
        while (x / 2 != 1) {
            x /= 2;
            n += 1;
        }
        return n;
    }
}
