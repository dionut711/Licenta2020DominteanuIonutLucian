package models;

public enum Algorithm {
    BUBBLE,
    INSERTION,
    ODD_EVEN_MERGE
}
