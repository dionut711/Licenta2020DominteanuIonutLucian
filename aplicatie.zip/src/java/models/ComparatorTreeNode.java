package models;

import sorting_networks.Comparator;

public class ComparatorTreeNode {
    private boolean isComparator;
    private boolean isDepth;

    private int depth;
    private Comparator comparator;

    public ComparatorTreeNode(int depth) {
        setDepth(depth);
    }

    public ComparatorTreeNode(Comparator comparator) {
        this.comparator = comparator;
        setComparator(comparator);
    }

    public boolean isComparator() {
        return isComparator;
    }

    public Comparator getComparator() {
        return comparator;
    }

    public void setComparator(Comparator comparator) {
        this.comparator = comparator;
        isComparator = true;
        isDepth = false;
    }

    public boolean isDepth() {
        return isDepth;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
        isDepth = true;
        isComparator = false;
    }

    @Override
    public String toString() {
        if (isComparator) {
            return String.format("(%d, %d)", comparator.getX(), comparator.getY());
        } else {
            return "Depth: " + depth;
        }
    }
}
